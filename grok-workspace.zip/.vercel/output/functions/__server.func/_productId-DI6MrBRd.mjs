import { o as require_jsx_runtime } from "./_libs/@radix-ui/react-collection+[...].mjs";
import { b as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { g as ArrowLeft } from "./_libs/lucide-react.mjs";
import { l as formatMoney, n as Route, o as useShop } from "./_ssr/router-CF840eyW.mjs";
import { t as Button } from "./_ssr/button-4fBtMGGb.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_productId-DI6MrBRd.js
var import_jsx_runtime = require_jsx_runtime();
function ProductPage() {
	const { productId } = Route.useParams();
	const product = useShop((s) => s.products.find((p) => p.id === productId));
	const currency = useShop((s) => s.settings.currency);
	const addToCart = useShop((s) => s.addToCart);
	if (!product) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "py-16 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-muted",
			children: "That product is no longer listed."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			asChild: true,
			className: "mt-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/shop",
				children: "Back to shop"
			})
		})]
	});
	const soldOut = product.stock <= 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/shop",
		className: "mb-6 inline-flex items-center gap-2 text-sm text-muted hover:text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" }), "All products"]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-8 md:grid-cols-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "overflow-hidden rounded-xl bg-surface shadow-[var(--shadow-border)]",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: product.image,
				alt: product.name,
				className: "aspect-square w-full object-cover"
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: product.category
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-1 font-display text-3xl font-medium",
				children: product.name
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 font-display text-2xl tabular-nums",
				children: formatMoney(product.price, currency)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 max-w-md text-muted",
				children: product.description
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-muted",
				children: soldOut ? "Currently sold out" : `${product.stock} in stock`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "lg",
				className: "mt-6 w-full sm:w-auto",
				disabled: soldOut,
				onClick: () => addToCart(product.id),
				children: soldOut ? "Sold out" : "Add to bag"
			})
		] })]
	})] });
}
//#endregion
export { ProductPage as component };
