//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-e1EbCw_1.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/admin",
			"/checkout",
			"/evaluate",
			"/shop"
		],
		preloads: ["/assets/index-ini2usdS.js", "/assets/link-CGcfQkun.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-ini2usdS.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-Nt0P2ghG.js",
			"/assets/message-circle-Dkc_nEAn.js",
			"/assets/button-CeTsFftC.js"
		]
	},
	"/admin": {
		filePath: "/workspace/src/routes/admin.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-QH_h20eY.js",
			"/assets/store-shell-BveH9-XF.js",
			"/assets/button-CeTsFftC.js",
			"/assets/label-CVFQ3EA7.js",
			"/assets/textarea-DaOmJK3b.js"
		]
	},
	"/checkout": {
		filePath: "/workspace/src/routes/checkout.tsx",
		children: void 0,
		preloads: [
			"/assets/checkout-DWnZjeUi.js",
			"/assets/store-shell-BveH9-XF.js",
			"/assets/message-circle-Dkc_nEAn.js",
			"/assets/button-CeTsFftC.js",
			"/assets/label-CVFQ3EA7.js",
			"/assets/textarea-DaOmJK3b.js"
		]
	},
	"/evaluate": {
		filePath: "/workspace/src/routes/evaluate.tsx",
		children: void 0,
		preloads: [
			"/assets/evaluate-BcjICCWk.js",
			"/assets/store-shell-BveH9-XF.js",
			"/assets/button-CeTsFftC.js",
			"/assets/label-CVFQ3EA7.js"
		]
	},
	"/shop": {
		filePath: "/workspace/src/routes/shop.tsx",
		children: ["/shop/$productId", "/shop/"],
		preloads: ["/assets/shop-Bon0qyNa.js", "/assets/store-shell-BveH9-XF.js"]
	},
	"/shop/$productId": {
		filePath: "/workspace/src/routes/shop/$productId.tsx",
		children: void 0,
		preloads: ["/assets/_productId-CVv8SicC.js", "/assets/button-CeTsFftC.js"]
	},
	"/shop/": {
		filePath: "/workspace/src/routes/shop/index.tsx",
		children: void 0,
		preloads: ["/assets/shop-BLg-CIj8.js", "/assets/button-CeTsFftC.js"]
	}
} });
//#endregion
export { tsrStartManifest };
