import { i as __toESM } from "../_runtime.mjs";
import { o as require_jsx_runtime, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { b as Link, p as useRouterState } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as Plus, d as MessageCircle, i as Trash2, o as ShoppingBag, t as X, u as Minus } from "../_libs/lucide-react.mjs";
import { a as DialogOverlay, i as DialogDescription, n as DialogClose, o as DialogPortal, r as DialogContent, s as DialogTitle, t as Dialog } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { a as cartSubtotal, c as digitsOnly, i as cartLines, l as formatMoney, o as useShop, r as cartCount } from "./router-CF840eyW.mjs";
import { n as cn, t as Button } from "./button-4fBtMGGb.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/store-shell-B4L6LZBj.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Sheet = Dialog;
function SheetContent({ className, children, side = "right", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "fixed inset-0 z-50 bg-fg/40" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
		className: cn("fixed top-0 z-50 flex h-full w-[min(100%,420px)] flex-col bg-surface text-fg shadow-[var(--shadow-border-hover)]", "transition-transform duration-250 ease-[cubic-bezier(0.22,1,0.36,1)]", side === "right" ? "right-0" : "left-0", className),
		...props,
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
			className: "absolute right-4 top-4 rounded-sm p-1 text-muted hover:text-fg",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "sr-only",
				children: "Close"
			})]
		})]
	})] });
}
function SheetHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("space-y-1 p-6 pr-12", className),
		...props
	});
}
function SheetTitle({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
		className: cn("font-display text-xl font-medium", className),
		...props
	});
}
function SheetDescription({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
		className: cn("text-sm text-muted", className),
		...props
	});
}
function CartSheet() {
	const open = useShop((s) => s.cartOpen);
	const setCartOpen = useShop((s) => s.setCartOpen);
	const cart = useShop((s) => s.cart);
	const products = useShop((s) => s.products);
	const settings = useShop((s) => s.settings);
	const setQty = useShop((s) => s.setQty);
	const removeFromCart = useShop((s) => s.removeFromCart);
	const lines = cartLines({
		cart,
		products
	});
	const subtotal = cartSubtotal(lines);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
		open,
		onOpenChange: setCartOpen,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, { children: "Your bag" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetDescription, { children: lines.length === 0 ? "Nothing in here yet." : `${lines.length} ${lines.length === 1 ? "item" : "items"}` })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex min-h-0 flex-1 flex-col",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex-1 overflow-y-auto px-6",
				children: lines.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Browse the shop and add a few things. You can check out by EFT or WhatsApp."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-4",
					children: lines.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: line.image,
							alt: "",
							className: "size-20 rounded-md object-cover"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate font-medium",
									children: line.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm tabular-nums text-muted",
									children: formatMoney(line.price, settings.currency)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-2 flex items-center gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											variant: "outline",
											size: "icon",
											className: "size-8",
											"aria-label": "Decrease quantity",
											onClick: () => setQty(line.productId, line.qty - 1),
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, {})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "w-6 text-center text-sm tabular-nums",
											children: line.qty
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											variant: "outline",
											size: "icon",
											className: "size-8",
											"aria-label": "Increase quantity",
											onClick: () => setQty(line.productId, line.qty + 1),
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											variant: "ghost",
											size: "icon",
											className: "ml-auto size-8 text-muted",
											"aria-label": `Remove ${line.name}`,
											onClick: () => removeFromCart(line.productId),
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {})
										})
									]
								})
							]
						})]
					}, line.productId))
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border-t border-border p-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-4 flex items-center justify-between text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-muted",
						children: "Subtotal"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums font-medium",
						children: formatMoney(subtotal, settings.currency)
					})]
				}), lines.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "w-full",
					disabled: true,
					children: "Checkout"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					className: "w-full",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/checkout",
						onClick: () => setCartOpen(false),
						children: "Checkout"
					})
				})]
			})]
		})] })
	});
}
var NAV = [
	{
		to: "/shop",
		label: "Shop",
		exact: true
	},
	{
		to: "/evaluate",
		label: "Evaluator"
	},
	{
		to: "/admin",
		label: "Admin"
	}
];
function StoreHeader() {
	const settings = useShop((s) => s.settings);
	const cart = useShop((s) => s.cart);
	const setCartOpen = useShop((s) => s.setCartOpen);
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const count = cartCount(cart);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "sticky top-0 z-40 border-b border-border bg-bg/90 backdrop-blur-md",
		children: [settings.announcement ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "bg-primary px-4 py-2 text-center text-xs font-medium tracking-wide text-primary-fg",
			children: settings.announcement
		}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex h-16 max-w-6xl items-center justify-between gap-3 px-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/shop",
					className: "flex min-w-0 items-center gap-2.5",
					children: [settings.logo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: settings.logo,
						alt: "",
						className: "size-8 rounded-sm object-cover"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "flex size-8 items-center justify-center rounded-sm bg-primary font-display text-sm text-primary-fg",
						children: settings.name.slice(0, 1)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "truncate font-display text-lg font-medium tracking-tight",
						children: settings.name
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "hidden items-center gap-1 md:flex",
					children: NAV.map((item) => {
						const active = "exact" in item && item.exact ? pathname === item.to : pathname.startsWith(item.to);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: item.to,
							className: cn("rounded-md px-3 py-2 text-sm font-medium transition-colors duration-150", active ? "bg-surface text-fg" : "text-muted hover:text-fg"),
							children: item.label
						}, item.to);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/admin",
						className: "rounded-md px-3 py-2 text-sm font-medium text-muted hover:text-fg md:hidden",
						children: "Admin"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "secondary",
						size: "icon",
						"aria-label": `Open bag, ${count} items`,
						onClick: () => setCartOpen(true),
						className: "relative",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingBag, {}), count > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "absolute -right-1 -top-1 flex size-5 items-center justify-center rounded-full bg-primary text-[10px] font-semibold text-primary-fg tabular-nums",
							children: count
						}) : null]
					})]
				})
			]
		})]
	});
}
function StoreTheme() {
	const color = useShop((s) => s.settings.primaryColor);
	(0, import_react.useEffect)(() => {
		const root = document.documentElement;
		root.style.setProperty("--color-primary", color);
		root.style.setProperty("--color-ring", color);
		return () => {
			root.style.removeProperty("--color-primary");
			root.style.removeProperty("--color-ring");
		};
	}, [color]);
	return null;
}
function waLink(phone, text) {
	return `https://wa.me/${digitsOnly(phone)}?text=${encodeURIComponent(text)}`;
}
function enquiryMessage(settings) {
	return `Hi ${settings.name}, I'd like to ask about your products.`;
}
function orderMessage(opts) {
	const items = opts.lines.map((l) => `• ${l.qty}× ${l.name} — ${formatMoney(l.price * l.qty, opts.settings.currency)}`).join("\n");
	const delivery = opts.delivery ? `${opts.delivery.name} (${formatMoney(opts.delivery.price, opts.settings.currency)})` : "Not selected";
	const notes = opts.notes.trim() ? `\nNotes: ${opts.notes.trim()}` : "";
	return `New order for ${opts.settings.name}

${items}

Delivery: ${delivery}
Total: ${formatMoney(opts.total, opts.settings.currency)}
Reference: ${opts.reference}

Name: ${opts.customerName}
Phone: ${opts.phone}
Address: ${opts.address}${notes}

I'll pay by EFT using the reference above.`;
}
function WhatsappFab() {
	const settings = useShop((s) => s.settings);
	if (!settings.whatsapp) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
		href: waLink(settings.whatsapp, enquiryMessage(settings)),
		target: "_blank",
		rel: "noreferrer",
		className: "fixed bottom-6 left-4 z-40 inline-flex h-12 items-center gap-2 rounded-full bg-success px-4 text-sm font-medium text-surface shadow-[var(--shadow-border-hover)] transition-transform duration-150 active:scale-[0.96]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "size-4" }), "WhatsApp"]
	});
}
function StoreShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-bg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StoreTheme, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StoreHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "mx-auto w-full max-w-6xl px-4 py-8 pb-28",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartSheet, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhatsappFab, {})
		]
	});
}
//#endregion
export { orderMessage as n, waLink as r, StoreShell as t };
