import { i as __toESM } from "../_runtime.mjs";
import { o as require_jsx_runtime, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { c as Plus, i as Trash2 } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { l as formatMoney, o as useShop } from "./router-CF840eyW.mjs";
import { i as readFileAsDataUrl, n as cn, r as downloadJson, t as Button } from "./button-4fBtMGGb.mjs";
import { t as StoreShell } from "./store-shell-B4L6LZBj.mjs";
import { n as Label, t as Input } from "./label-BBUVDHv7.mjs";
import { t as Textarea } from "./textarea-p3ob5bt0.mjs";
import { i as Trigger, n as List, r as Root2, t as Content } from "../_libs/radix-ui__react-tabs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-CBwR0FGR.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Tabs = Root2;
function TabsList({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(List, {
		className: cn("flex flex-wrap gap-1 rounded-lg bg-bg p-1 shadow-[var(--shadow-border)]", className),
		...props
	});
}
function TabsTrigger({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trigger, {
		className: cn("inline-flex h-10 items-center justify-center rounded-md px-3 text-sm font-medium text-muted", "transition-colors duration-150 data-[state=active]:bg-surface data-[state=active]:text-fg data-[state=active]:shadow-[var(--shadow-border)]", className),
		...props
	});
}
function TabsContent({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content, {
		className: cn("mt-6 focus-visible:outline-none", className),
		...props
	});
}
function AdminPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(StoreShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-3xl font-medium",
			children: "Admin"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-muted",
			children: "This is your store. Change anything — it saves on this device."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
			defaultValue: "brand",
			className: "mt-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
						value: "brand",
						children: "Brand"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
						value: "products",
						children: "Products"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
						value: "delivery",
						children: "Delivery"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
						value: "bank",
						children: "Bank"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
						value: "orders",
						children: "Orders"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
						value: "backup",
						children: "Backup"
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
					value: "brand",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BrandPanel, {})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
					value: "products",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductsPanel, {})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
					value: "delivery",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeliveryPanel, {})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
					value: "bank",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BankPanel, {})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
					value: "orders",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrdersPanel, {})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
					value: "backup",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackupPanel, {})
				})
			]
		})
	] });
}
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-1.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: label }), children]
	});
}
function BrandPanel() {
	const settings = useShop((s) => s.settings);
	const updateSettings = useShop((s) => s.updateSettings);
	async function onLogo(file) {
		if (!file) return;
		const data = await readFileAsDataUrl(file);
		updateSettings({ logo: data });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "max-w-xl space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Store name",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: settings.name,
					onChange: (e) => updateSettings({ name: e.target.value })
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Tagline",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: settings.tagline,
					onChange: (e) => updateSettings({ tagline: e.target.value })
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Announcement bar",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: settings.announcement,
					onChange: (e) => updateSettings({ announcement: e.target.value })
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "WhatsApp number (with country code)",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: settings.whatsapp,
					onChange: (e) => updateSettings({ whatsapp: e.target.value })
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Currency",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: settings.currency,
					onChange: (e) => updateSettings({ currency: e.target.value.toUpperCase() })
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Brand colour",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "color",
					value: settings.primaryColor,
					onChange: (e) => updateSettings({ primaryColor: e.target.value }),
					className: "h-11 w-20 cursor-pointer rounded-md border border-border bg-surface"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Logo",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					type: "file",
					accept: "image/*",
					onChange: (e) => void onLogo(e.target.files?.[0])
				})
			}),
			settings.logo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: settings.logo,
				alt: "",
				className: "size-16 rounded-md object-cover"
			}) : null
		]
	});
}
function ProductsPanel() {
	const products = useShop((s) => s.products);
	const addProduct = useShop((s) => s.addProduct);
	const updateProduct = useShop((s) => s.updateProduct);
	const removeProduct = useShop((s) => s.removeProduct);
	const currency = useShop((s) => s.settings.currency);
	const [editing, setEditing] = (0, import_react.useState)(null);
	function startNew() {
		if (products.length >= 50) {
			toast.error(`Maximum 50 products`);
			return;
		}
		setEditing({
			id: typeof crypto !== "undefined" && crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}`,
			name: "",
			description: "",
			price: 0,
			image: "/products/candle.jpg",
			category: "Home",
			stock: 10,
			featured: false
		});
	}
	function save(product) {
		if (products.some((p) => p.id === product.id)) updateProduct(product.id, product);
		else if (!addProduct(product)) {
			toast.error(`Maximum 50 products`);
			return;
		}
		setEditing(null);
		toast.success("Product saved");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 flex items-center justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					products.length,
					" / ",
					50,
					" slots"
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				onClick: startNew,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), "Add product"]
			})]
		}),
		editing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductEditor, {
			product: editing,
			onCancel: () => setEditing(null),
			onSave: save
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-4 divide-y divide-border rounded-xl bg-surface shadow-[var(--shadow-border)]",
			children: products.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex items-center gap-3 p-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: p.image,
						alt: "",
						className: "size-14 rounded-md object-cover"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate font-medium",
							children: p.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted",
							children: [
								formatMoney(p.price, currency),
								" · ",
								p.stock,
								" in stock"
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "ghost",
						onClick: () => setEditing(p),
						children: "Edit"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "icon",
						variant: "ghost",
						"aria-label": `Delete ${p.name}`,
						onClick: () => removeProduct(p.id),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {})
					})
				]
			}, p.id))
		})
	] });
}
function ProductEditor({ product, onCancel, onSave }) {
	const [draft, setDraft] = (0, import_react.useState)(product);
	async function onImage(file) {
		if (!file) return;
		const data = await readFileAsDataUrl(file);
		setDraft((d) => ({
			...d,
			image: data
		}));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-6 space-y-3 rounded-xl bg-surface p-5 shadow-[var(--shadow-border)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Name",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: draft.name,
					onChange: (e) => setDraft((d) => ({
						...d,
						name: e.target.value
					}))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Description",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					value: draft.description,
					onChange: (e) => setDraft((d) => ({
						...d,
						description: e.target.value
					}))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Price",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							min: 0,
							value: draft.price,
							onChange: (e) => setDraft((d) => ({
								...d,
								price: Number(e.target.value) || 0
							}))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Stock",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							min: 0,
							value: draft.stock,
							onChange: (e) => setDraft((d) => ({
								...d,
								stock: Number(e.target.value) || 0
							}))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Category",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: draft.category,
							onChange: (e) => setDraft((d) => ({
								...d,
								category: e.target.value
							}))
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Photo",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					type: "file",
					accept: "image/*",
					onChange: (e) => void onImage(e.target.files?.[0])
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex items-center gap-2 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "checkbox",
					checked: draft.featured,
					onChange: (e) => setDraft((d) => ({
						...d,
						featured: e.target.checked
					}))
				}), "Featured on the shop home"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					onClick: () => onSave(draft),
					children: "Save"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "ghost",
					onClick: onCancel,
					children: "Cancel"
				})]
			})
		]
	});
}
function DeliveryPanel() {
	const delivery = useShop((s) => s.delivery);
	const addDelivery = useShop((s) => s.addDelivery);
	const updateDelivery = useShop((s) => s.updateDelivery);
	const removeDelivery = useShop((s) => s.removeDelivery);
	const currency = useShop((s) => s.settings.currency);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [delivery.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3 rounded-xl bg-surface p-4 shadow-[var(--shadow-border)] sm:grid-cols-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Name",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: d.name,
						onChange: (e) => updateDelivery(d.id, { name: e.target.value })
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: `Price (${currency})`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "number",
						min: 0,
						value: d.price,
						onChange: (e) => updateDelivery(d.id, { price: Number(e.target.value) || 0 })
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Description",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: d.description,
						onChange: (e) => updateDelivery(d.id, { description: e.target.value })
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Time",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: d.eta,
						onChange: (e) => updateDelivery(d.id, { eta: e.target.value })
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "ghost",
					size: "sm",
					className: "text-danger",
					onClick: () => removeDelivery(d.id),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {}), "Remove"]
				})
			]
		}, d.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			variant: "secondary",
			onClick: () => addDelivery({
				id: typeof crypto !== "undefined" && crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}`,
				name: "New option",
				description: "",
				price: 0,
				eta: "2–4 days"
			}),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), "Add delivery option"]
		})]
	});
}
function BankPanel() {
	const bank = useShop((s) => s.settings.bank);
	const updateBank = useShop((s) => s.updateBank);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "max-w-xl space-y-4",
		children: [
			["accountName", "Account name"],
			["bankName", "Bank"],
			["accountNumber", "Account number"],
			["branchCode", "Branch code"],
			["accountType", "Account type"]
		].map(([key, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			label,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				value: bank[key],
				onChange: (e) => updateBank({ [key]: e.target.value })
			})
		}, key))
	});
}
function OrdersPanel() {
	const orders = useShop((s) => s.orders);
	const currency = useShop((s) => s.settings.currency);
	if (orders.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted",
		children: "No orders yet. Place a test order from the shop to see it here."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "space-y-3",
		children: orders.map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "rounded-xl bg-surface p-4 text-sm shadow-[var(--shadow-border)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium",
						children: o.reference
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "tabular-nums",
						children: formatMoney(o.total, currency)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-muted",
					children: [
						o.customerName,
						" · ",
						o.phone
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-muted",
					children: o.items.map((i) => `${i.qty}× ${i.name}`).join(", ")
				})
			]
		}, o.id))
	});
}
function BackupPanel() {
	const settings = useShop((s) => s.settings);
	const products = useShop((s) => s.products);
	const delivery = useShop((s) => s.delivery);
	const orders = useShop((s) => s.orders);
	const restore = useShop((s) => s.restore);
	const resetDemo = useShop((s) => s.resetDemo);
	const fileRef = (0, import_react.useRef)(null);
	function onBackup() {
		downloadJson(`my-simple-store-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.json`, {
			settings,
			products,
			delivery,
			orders
		});
		toast.success("Backup downloaded");
	}
	async function onRestore(file) {
		if (!file) return;
		try {
			const text = await file.text();
			const data = JSON.parse(text);
			if (!data.settings || !Array.isArray(data.products)) throw new Error("Not a store backup");
			restore({
				settings: data.settings,
				products: data.products,
				delivery: data.delivery ?? [],
				orders: data.orders ?? []
			});
			toast.success("Store restored");
		} catch {
			toast.error("Could not read that file");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "max-w-xl space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Download a copy of your store, or restore one. Reset returns the demo products."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: onBackup,
						children: "Download backup"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "secondary",
						onClick: () => fileRef.current?.click(),
						children: "Restore backup"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						className: "text-danger",
						onClick: () => {
							resetDemo();
							toast.success("Demo store restored");
						},
						children: "Reset demo"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: fileRef,
				type: "file",
				accept: "application/json",
				className: "hidden",
				onChange: (e) => void onRestore(e.target.files?.[0])
			})
		]
	});
}
//#endregion
export { AdminPage as component };
