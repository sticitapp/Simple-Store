import { i as __toESM } from "../_runtime.mjs";
import { o as require_jsx_runtime, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { l as formatMoney, o as useShop } from "./router-CF840eyW.mjs";
import { n as cn, t as Button } from "./button-4fBtMGGb.mjs";
import { t as StoreShell } from "./store-shell-B4L6LZBj.mjs";
import { n as Label, t as Input } from "./label-BBUVDHv7.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/evaluate-B6m6WPfj.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var LEVEL = {
	low: 1,
	medium: 2,
	high: 3
};
function evaluateProduct(input) {
	const margin = input.sell > 0 ? (input.sell - input.cost) / input.sell : 0;
	let score = 0;
	const reasons = [];
	if (margin >= .6) {
		score += 30;
		reasons.push({
			label: "Strong margin",
			detail: `${Math.round(margin * 100)}% left after cost — room for ads, returns and delivery.`,
			tone: "good"
		});
	} else if (margin >= .4) {
		score += 22;
		reasons.push({
			label: "Healthy margin",
			detail: `${Math.round(margin * 100)}% is workable if shipping stays cheap.`,
			tone: "good"
		});
	} else if (margin >= .25) {
		score += 12;
		reasons.push({
			label: "Tight margin",
			detail: `${Math.round(margin * 100)}% — one return or a courier hike wipes the profit.`,
			tone: "warn"
		});
	} else {
		score += 4;
		reasons.push({
			label: "Weak margin",
			detail: "Selling price is too close to cost. Raise price or find a cheaper supplier.",
			tone: "bad"
		});
	}
	score += LEVEL[input.demand] * 10;
	if (input.demand === "high") reasons.push({
		label: "Demand looks real",
		detail: "People already search for and buy this kind of product.",
		tone: "good"
	});
	else if (input.demand === "low") reasons.push({
		label: "Quiet demand",
		detail: "You will have to create the market, not just stock it.",
		tone: "warn"
	});
	score += (4 - LEVEL[input.competition]) * 8;
	if (input.competition === "high") reasons.push({
		label: "Crowded category",
		detail: "Price and photos will have to work harder than the product itself.",
		tone: "warn"
	});
	else if (input.competition === "low") reasons.push({
		label: "Open lane",
		detail: "Fewer lookalikes — easier to own the search and the look.",
		tone: "good"
	});
	score += (4 - (input.shipping === "easy" ? 1 : input.shipping === "typical" ? 2 : 3)) * 6;
	if (input.shipping === "hard") reasons.push({
		label: "Painful to ship",
		detail: "Bulky, heavy or awkward parcels eat margin and cause damage claims.",
		tone: "bad"
	});
	else if (input.shipping === "easy") reasons.push({
		label: "Ships cleanly",
		detail: "Small and light — cheaper courier and fewer broken-in-transit issues.",
		tone: "good"
	});
	score += LEVEL[input.uniqueness] * 5;
	if (input.uniqueness === "high") reasons.push({
		label: "Ownable product",
		detail: "A distinctive item is easier to brand and harder to undercut.",
		tone: "good"
	});
	if (input.trend === "evergreen") {
		score += 10;
		reasons.push({
			label: "Evergreen",
			detail: "Sells in more than one season — leftover stock is less of a bet.",
			tone: "good"
		});
	} else if (input.trend === "seasonal") {
		score += 5;
		reasons.push({
			label: "Seasonal",
			detail: "Plan stock around a window. Miss it and you sit on inventory.",
			tone: "warn"
		});
	} else reasons.push({
		label: "Trend risk",
		detail: "Fads fade. Only stock what you can sell in weeks, not months.",
		tone: "bad"
	});
	if (input.fragility) {
		score -= 8;
		reasons.push({
			label: "Fragile",
			detail: "Extra packing cost and a higher chance of refunds.",
			tone: "warn"
		});
	}
	score = Math.max(0, Math.min(100, Math.round(score)));
	const grade = score >= 80 ? "A" : score >= 65 ? "B" : score >= 50 ? "C" : score >= 35 ? "D" : "F";
	const verdict = grade === "A" ? "Stock it. The numbers and the market both support a listing." : grade === "B" ? "Worth selling — keep a tight hold on cost and shipping." : grade === "C" ? "Only if you already have an audience or a cheaper source." : grade === "D" ? "Risky. Change price, supplier or product before you buy in bulk." : "Skip it. The margin, demand or logistics do not add up.";
	const marginLabel = margin <= 0 ? "Loss" : `${Math.round(margin * 100)}% margin`;
	return {
		score,
		grade,
		verdict,
		margin,
		marginLabel,
		reasons
	};
}
function EvaluatePage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StoreShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EvaluateInner, {}) });
}
var DEMAND = [
	{
		id: "low",
		label: "Low"
	},
	{
		id: "medium",
		label: "Medium"
	},
	{
		id: "high",
		label: "High"
	}
];
function EvaluateInner() {
	const currency = useShop((s) => s.settings.currency);
	const [input, setInput] = (0, import_react.useState)({
		name: "",
		cost: 80,
		sell: 185,
		demand: "medium",
		competition: "medium",
		shipping: "easy",
		uniqueness: "medium",
		trend: "evergreen",
		fragility: false
	});
	const result = (0, import_react.useMemo)(() => evaluateProduct(input), [input]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-8 lg:grid-cols-[1fr_340px]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium text-primary",
				children: "Before you stock it"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-1 font-display text-3xl font-medium",
				children: "Product evaluator"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-xl text-muted",
				children: "Score a product for resale. Honest numbers beat a pretty photo — this is the tool included with My Simple Store."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 space-y-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "eval-name",
							children: "Product name"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "eval-name",
							placeholder: "Amber cedar candle",
							value: input.name,
							onChange: (e) => setInput((s) => ({
								...s,
								name: e.target.value
							}))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "eval-cost",
								children: "Your cost"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "eval-cost",
								type: "number",
								min: 0,
								value: input.cost,
								onChange: (e) => setInput((s) => ({
									...s,
									cost: Number(e.target.value) || 0
								}))
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "eval-sell",
								children: "Selling price"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "eval-sell",
								type: "number",
								min: 0,
								value: input.sell,
								onChange: (e) => setInput((s) => ({
									...s,
									sell: Number(e.target.value) || 0
								}))
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
						label: "Customer demand",
						value: input.demand,
						options: DEMAND,
						onChange: (demand) => setInput((s) => ({
							...s,
							demand
						}))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
						label: "Competition",
						value: input.competition,
						options: DEMAND,
						onChange: (competition) => setInput((s) => ({
							...s,
							competition
						}))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
						label: "How hard to ship",
						value: input.shipping,
						options: [
							{
								id: "easy",
								label: "Easy"
							},
							{
								id: "typical",
								label: "Typical"
							},
							{
								id: "hard",
								label: "Hard"
							}
						],
						onChange: (shipping) => setInput((s) => ({
							...s,
							shipping
						}))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
						label: "How unique",
						value: input.uniqueness,
						options: DEMAND,
						onChange: (uniqueness) => setInput((s) => ({
							...s,
							uniqueness
						}))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
						label: "Trend",
						value: input.trend,
						options: [
							{
								id: "evergreen",
								label: "Evergreen"
							},
							{
								id: "seasonal",
								label: "Seasonal"
							},
							{
								id: "fad",
								label: "Fad"
							}
						],
						onChange: (trend) => setInput((s) => ({
							...s,
							trend
						}))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-center gap-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: input.fragility,
							onChange: (e) => setInput((s) => ({
								...s,
								fragility: e.target.checked
							}))
						}), "Fragile — extra packing or breakage risk"]
					})
				]
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "h-fit rounded-xl bg-surface p-6 shadow-[var(--shadow-border)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Resale score"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 font-display text-5xl font-medium tabular-nums",
					children: [result.score, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "ml-2 text-2xl text-muted",
						children: result.grade
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm",
					children: result.verdict
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-sm text-muted",
					children: [
						formatMoney(input.cost, currency),
						" in ·",
						" ",
						formatMoney(input.sell, currency),
						" out · ",
						result.marginLabel
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-5 space-y-3",
					children: result.reasons.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: cn("font-medium", r.tone === "good" && "text-success", r.tone === "warn" && "text-accent", r.tone === "bad" && "text-danger"),
							children: r.label
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-muted",
							children: r.detail
						})]
					}, r.label))
				})
			]
		})]
	});
}
function Choice({ label, value, options, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
		className: "mb-2 text-sm font-medium",
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex flex-wrap gap-1",
		children: options.map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			type: "button",
			size: "sm",
			variant: value === o.id ? "default" : "outline",
			onClick: () => onChange(o.id),
			children: o.label
		}, o.id))
	})] });
}
//#endregion
export { EvaluatePage as component };
