import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Smartphone, d as MessageCircle, f as Download, h as ArrowRight, l as Palette, m as Banknote, n as Truck, p as Check, s as ScanSearch } from "../_libs/lucide-react.mjs";
import { t as Button } from "./button-4fBtMGGb.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BR2DHed6.js
var import_jsx_runtime = require_jsx_runtime();
var FEATURES = [
	{
		icon: Palette,
		title: "Your brand, your logo",
		body: "Change the store name, logo and colour in seconds. Make it look like your own business."
	},
	{
		icon: ScanSearch,
		title: "Fifty product slots",
		body: "Add photos, prices and descriptions. Edit or remove them whenever you like."
	},
	{
		icon: Banknote,
		title: "Paid into your bank",
		body: "Buyers pay you by EFT. You keep all of the money — no platform cut."
	},
	{
		icon: MessageCircle,
		title: "WhatsApp orders",
		body: "A floating button and a ready-made order message, so people can buy in one tap."
	},
	{
		icon: Truck,
		title: "Delivery options",
		body: "Add collection, courier and locker prices. The total updates at checkout."
	},
	{
		icon: ScanSearch,
		title: "Product evaluator",
		body: "Score anything for resale before you stock it. Know what is worth buying."
	},
	{
		icon: Smartphone,
		title: "Installs like an app",
		body: "Add it to a phone home screen. It works on computer and phone."
	},
	{
		icon: Download,
		title: "Backup and restore",
		body: "Download your full store anytime. Never lose products or settings."
	}
];
var FAQS = [
	{
		q: "Do I need technical skills?",
		a: "No. Change the name, logo, products and bank details from the Admin panel. Everything is point and click."
	},
	{
		q: "How do customers pay me?",
		a: "They see your bank details at checkout and pay by EFT. They can also send the order on WhatsApp."
	},
	{
		q: "Is there a monthly fee later?",
		a: "No. One payment and the store is yours. Optional upgrades, if they ever exist, stay optional."
	},
	{
		q: "Can I run more than one store?",
		a: "Yes. Reset or restore a backup to run a different brand. Each copy keeps its own products."
	}
];
var MOSAIC = [
	"/products/candle.jpg",
	"/products/throw.jpg",
	"/products/protea.jpg",
	"/products/mug.jpg"
];
function Landing() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				className: "sticky top-0 z-40 flex items-center justify-between border-b border-border bg-bg/90 px-4 py-3 backdrop-blur-md",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "font-display text-lg font-medium tracking-tight",
					children: "My Simple Store"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "sm",
						asChild: true,
						className: "hidden sm:inline-flex",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/evaluate",
							children: "Evaluator"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						size: "sm",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/shop",
							children: ["Open live store", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})]
						})
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mx-auto grid max-w-6xl items-center gap-10 px-4 py-14 md:grid-cols-2 md:py-20",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "stagger-in",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium text-primary",
							children: "For small sellers who will not pay Shopify rent"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-3 font-display text-4xl font-medium tracking-tight md:text-5xl",
							children: "Your own online store. One payment. Yours."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 max-w-md text-muted",
							children: "Add your logo, products and bank details and start selling. No monthly fees, no plugins, no coding."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 flex flex-wrap items-end gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-4xl font-medium text-primary",
								children: "$30"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "pb-1 text-sm text-muted",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mr-2 line-through",
									children: "$97"
								}), " one-time"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 flex flex-wrap gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "lg",
								asChild: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/shop",
									children: ["Try the live store", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "lg",
								variant: "secondary",
								asChild: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/admin",
									children: "Open admin"
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-sm text-muted",
							children: "Instant demo · Phone and computer · No coding"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 gap-3",
					children: MOSAIC.map((src, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src,
						alt: "",
						className: `aspect-square w-full rounded-xl object-cover shadow-[var(--shadow-border)] ${i % 2 === 1 ? "mt-6" : ""}`
					}, src))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mx-auto max-w-6xl px-4 py-16",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-center font-display text-3xl font-medium",
						children: "Everything you need to start selling"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mx-auto mt-2 max-w-lg text-center text-muted",
						children: "Built for people who just want to sell products without expensive platforms."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4",
						children: FEATURES.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "rounded-xl bg-surface p-5 shadow-[var(--shadow-border)]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(f.icon, { className: "size-5 text-primary" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-3 font-medium",
									children: f.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm text-muted",
									children: f.body
								})
							]
						}, f.title))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mx-auto max-w-6xl px-4 py-16",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-center font-display text-3xl font-medium",
						children: "Why people choose it"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mx-auto mt-2 max-w-lg text-center text-muted",
						children: "Stop paying monthly fees for features you do not need."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-10 overflow-x-auto rounded-xl bg-surface shadow-[var(--shadow-border)]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "w-full min-w-[640px] text-left text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
								className: "bg-primary text-primary-fg",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-4 py-3 font-medium",
										children: "Feature"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-4 py-3 font-medium",
										children: "Shopify"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-4 py-3 font-medium",
										children: "WooCommerce"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-4 py-3 font-medium",
										children: "My Simple Store"
									})
								] })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: [
								[
									"Monthly cost",
									"$29–$299+",
									"Hosting + plugins",
									"$0 after purchase"
								],
								[
									"Setup",
									"Medium",
									"Hard",
									"Very easy"
								],
								[
									"Your branding",
									"Yes",
									"Yes",
									"Yes"
								],
								[
									"Bank transfer checkout",
									"Extra fees",
									"Plugins",
									"Built in"
								],
								[
									"WhatsApp ordering",
									"Paid apps",
									"Plugins",
									"Built in"
								],
								[
									"Product resale score",
									"No",
									"No",
									"Included"
								],
								[
									"One-time price",
									"No",
									"No",
									"Only $30"
								]
							].map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
								className: "border-t border-border",
								children: row.map((cell, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: `px-4 py-3 ${i === 3 ? "font-medium text-primary" : ""}`,
									children: cell
								}, i))
							}, row[0])) })]
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				id: "buy",
				className: "mx-auto max-w-6xl px-4 py-16",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-center font-display text-3xl font-medium",
						children: "Simple pricing"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-center text-muted",
						children: "Pay once. Use forever."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto mt-10 max-w-md rounded-xl bg-surface p-8 text-center shadow-[var(--shadow-border)]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-medium uppercase tracking-wide text-primary",
								children: "Lifetime access"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 font-display text-5xl font-medium text-primary",
								children: "$30"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted",
								children: "One-time · no monthly fees"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mx-auto mt-6 max-w-xs space-y-2 text-left text-sm",
								children: [
									"Full store (installable)",
									"50 product slots",
									"Custom logo and branding",
									"Bank transfer checkout",
									"WhatsApp order button",
									"Delivery options",
									"Product resale evaluator",
									"Backup and restore"
								].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4 text-success" }), item]
								}, item))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "lg",
								className: "mt-8 w-full",
								asChild: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/shop",
									children: ["Get instant access", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-xs text-muted",
								children: "Opens the live demo store. Customise it in Admin — this is the product."
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mx-auto max-w-3xl px-4 py-16",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-center font-display text-3xl font-medium",
					children: "Questions"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-8 space-y-3",
					children: FAQS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-lg bg-surface px-5 py-4 shadow-[var(--shadow-border)]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-medium",
							children: item.q
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted",
							children: item.a
						})]
					}, item.q))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "bg-primary px-4 py-16 text-center text-primary-fg",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-3xl font-medium",
						children: "Ready to start selling?"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mx-auto mt-2 max-w-md text-primary-fg/85",
						children: "Open the demo, change the name, add your bank details, and treat it as your shop."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "lg",
						className: "mt-8 bg-surface text-fg hover:opacity-95",
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/shop",
							children: ["Open My Simple Store", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})]
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "px-4 py-8 text-center text-sm text-muted",
				children: "© 2026 My Simple Store · Built for people who just want to sell"
			})
		]
	});
}
//#endregion
export { Landing as component };
