import { i as __toESM } from "../_runtime.mjs";
import { o as require_jsx_runtime, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { _ as lazyRouteComponent, d as Scripts, f as HeadContent, g as Outlet, h as createRouter, v as createFileRoute, x as useRouter, y as createRootRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as TriangleAlert } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-CF840eyW.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var CURRENCY_LOCALES = {
	ZAR: "en-ZA",
	USD: "en-US",
	GBP: "en-GB",
	EUR: "en-IE",
	AUD: "en-AU"
};
function formatMoney(amount, currency = "ZAR") {
	const locale = CURRENCY_LOCALES[currency] ?? "en-ZA";
	try {
		return new Intl.NumberFormat(locale, {
			style: "currency",
			currency,
			maximumFractionDigits: 0
		}).format(amount);
	} catch {
		return `${currency} ${amount}`;
	}
}
function formatOrderRef(id) {
	return `MSS-${id.slice(0, 6).toUpperCase()}`;
}
function digitsOnly(value) {
	return value.replace(/\D/g, "");
}
var DEFAULT_SETTINGS = {
	name: "Saffron Street",
	tagline: "Quiet objects for a slower home.",
	logo: null,
	primaryColor: "#5b21b6",
	whatsapp: "27821234567",
	currency: "ZAR",
	announcement: "Free collection in Cape Town · EFT or WhatsApp to order",
	bank: {
		accountName: "Saffron Street Studio",
		bankName: "Standard Bank",
		accountNumber: "123456789",
		branchCode: "051001",
		accountType: "Business current"
	}
};
var DEFAULT_PRODUCTS = [
	{
		id: "candle",
		name: "Amber Cedar Candle",
		description: "Hand-poured soy wax in a re-usable amber jar. Cedarwood, smoke and a little sweet orange. Burns about 40 hours.",
		price: 185,
		image: "/products/candle.jpg",
		category: "Home",
		stock: 18,
		featured: true
	},
	{
		id: "throw",
		name: "Oatmeal Linen Throw",
		description: "Washed European linen, 140 × 200 cm. Soft from the first evening on the sofa. Stone-washed so it never looks stiff.",
		price: 650,
		image: "/products/throw.jpg",
		category: "Home",
		stock: 7,
		featured: true
	},
	{
		id: "mug",
		name: "Speckled Stoneware Mug",
		description: "Thrown in small batches. Oatmeal glaze with a dark speckled clay body. Holds 350 ml — a proper morning cup.",
		price: 145,
		image: "/products/mug.jpg",
		category: "Home",
		stock: 24,
		featured: false
	},
	{
		id: "soap",
		name: "Botanical Soap Trio",
		description: "Three cold-process bars: rosemary, oatmeal honey, and clay. Dried petals on the face, no plastic wrap.",
		price: 220,
		image: "/products/soap.jpg",
		category: "Body",
		stock: 15,
		featured: false
	},
	{
		id: "incense",
		name: "Brass Incense Dish",
		description: "Hammered brass, roughly 10 cm across. Catches ash cleanly and ages to a softer gold. Incense stick included.",
		price: 165,
		image: "/products/incense.jpg",
		category: "Home",
		stock: 12,
		featured: false
	},
	{
		id: "basket",
		name: "Seagrass Market Basket",
		description: "Handwoven seagrass with vegetable-tanned leather handles. Weekend market size — sturdy enough for bottles.",
		price: 380,
		image: "/products/basket.jpg",
		category: "Home",
		stock: 9,
		featured: true
	},
	{
		id: "face-oil",
		name: "Rosehip Face Oil",
		description: "Cold-pressed rosehip with a drop of vitamin E. 30 ml glass dropper. For dry skin, scars, and winter cheeks.",
		price: 295,
		image: "/products/face-oil.jpg",
		category: "Body",
		stock: 20,
		featured: true
	},
	{
		id: "necklace",
		name: "Terracotta Collar Necklace",
		description: "Hand-strung clay, cream bone and brass beads. Sits close to the collarbone. Each one is slightly different.",
		price: 420,
		image: "/products/necklace.jpg",
		category: "Wear",
		stock: 6,
		featured: false
	},
	{
		id: "tea-towel",
		name: "Botanical Linen Tea Towel",
		description: "Heavy linen with a sage and terracotta plant print. Absorbent enough for dishes, handsome enough on a hook.",
		price: 125,
		image: "/products/tea-towel.jpg",
		category: "Home",
		stock: 30,
		featured: false
	},
	{
		id: "protea",
		name: "Dried Protea Bunch",
		description: "Cape protea and eucalyptus, tied with twine. Lasts months in a dry room. No water, no fuss.",
		price: 240,
		image: "/products/protea.jpg",
		category: "Botanicals",
		stock: 11,
		featured: true
	}
];
var DEFAULT_DELIVERY = [
	{
		id: "collect",
		name: "Collection",
		description: "Pick up from the studio in Woodstock, Cape Town.",
		price: 0,
		eta: "Same day"
	},
	{
		id: "local",
		name: "Cape Town courier",
		description: "Door to door in greater Cape Town.",
		price: 75,
		eta: "1–2 days"
	},
	{
		id: "national",
		name: "National courier",
		description: "Door to door anywhere in South Africa.",
		price: 120,
		eta: "2–5 days"
	},
	{
		id: "paxi",
		name: "Pep Paxi",
		description: "Collect at your nearest Pep or Ackermans.",
		price: 65,
		eta: "3–6 days"
	}
];
var CATEGORIES = [
	"All",
	"Home",
	"Body",
	"Wear",
	"Botanicals"
];
function linesFrom(cart, products) {
	return cart.map((item) => {
		const product = products.find((p) => p.id === item.productId);
		if (!product) return null;
		return {
			productId: product.id,
			name: product.name,
			price: product.price,
			image: product.image,
			qty: item.qty
		};
	}).filter((x) => x !== null);
}
function cartLines(state) {
	return linesFrom(state.cart, state.products);
}
function cartCount(cart) {
	return cart.reduce((sum, item) => sum + item.qty, 0);
}
function cartSubtotal(lines) {
	return lines.reduce((sum, line) => sum + line.price * line.qty, 0);
}
var useShop = create()(persist((set, get) => ({
	settings: DEFAULT_SETTINGS,
	products: DEFAULT_PRODUCTS,
	delivery: DEFAULT_DELIVERY,
	cart: [],
	orders: [],
	cartOpen: false,
	setCartOpen: (open) => set({ cartOpen: open }),
	updateSettings: (patch) => set((s) => ({ settings: {
		...s.settings,
		...patch
	} })),
	updateBank: (patch) => set((s) => ({ settings: {
		...s.settings,
		bank: {
			...s.settings.bank,
			...patch
		}
	} })),
	addProduct: (product) => {
		const { products } = get();
		if (products.length >= 50) return false;
		set({ products: [product, ...products] });
		return true;
	},
	updateProduct: (id, patch) => set((s) => ({ products: s.products.map((p) => p.id === id ? {
		...p,
		...patch
	} : p) })),
	removeProduct: (id) => set((s) => ({
		products: s.products.filter((p) => p.id !== id),
		cart: s.cart.filter((c) => c.productId !== id)
	})),
	addDelivery: (option) => set((s) => ({ delivery: [...s.delivery, option] })),
	updateDelivery: (id, patch) => set((s) => ({ delivery: s.delivery.map((d) => d.id === id ? {
		...d,
		...patch
	} : d) })),
	removeDelivery: (id) => set((s) => ({ delivery: s.delivery.filter((d) => d.id !== id) })),
	addToCart: (productId, qty = 1) => {
		const product = get().products.find((p) => p.id === productId);
		if (!product || product.stock <= 0) return;
		set((s) => {
			const existing = s.cart.find((c) => c.productId === productId);
			const nextQty = Math.min(product.stock, (existing?.qty ?? 0) + qty);
			return {
				cart: existing ? s.cart.map((c) => c.productId === productId ? {
					...c,
					qty: nextQty
				} : c) : [...s.cart, {
					productId,
					qty: nextQty
				}],
				cartOpen: true
			};
		});
	},
	setQty: (productId, qty) => set((s) => {
		const max = s.products.find((p) => p.id === productId)?.stock ?? 0;
		if (qty <= 0) return { cart: s.cart.filter((c) => c.productId !== productId) };
		return { cart: s.cart.map((c) => c.productId === productId ? {
			...c,
			qty: Math.min(max, qty)
		} : c) };
	}),
	removeFromCart: (productId) => set((s) => ({ cart: s.cart.filter((c) => c.productId !== productId) })),
	clearCart: () => set({ cart: [] }),
	placeOrder: (input) => {
		const state = get();
		const lines = linesFrom(state.cart, state.products);
		if (lines.length === 0) return null;
		const delivery = state.delivery.find((d) => d.id === input.deliveryId);
		const subtotal = cartSubtotal(lines);
		const deliveryPrice = delivery?.price ?? 0;
		const id = typeof crypto !== "undefined" && crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}`;
		const order = {
			id,
			createdAt: (/* @__PURE__ */ new Date()).toISOString(),
			customerName: input.customerName,
			phone: input.phone,
			email: input.email,
			address: input.address,
			notes: input.notes,
			deliveryId: input.deliveryId,
			items: lines.map((l) => ({
				productId: l.productId,
				name: l.name,
				qty: l.qty,
				price: l.price
			})),
			subtotal,
			deliveryPrice,
			total: subtotal + deliveryPrice,
			reference: formatOrderRef(id)
		};
		set((s) => ({
			orders: [order, ...s.orders],
			cart: [],
			products: s.products.map((p) => {
				const line = lines.find((l) => l.productId === p.id);
				if (!line) return p;
				return {
					...p,
					stock: Math.max(0, p.stock - line.qty)
				};
			})
		}));
		return order;
	},
	restore: (snapshot) => set({
		settings: snapshot.settings,
		products: snapshot.products.slice(0, 50),
		delivery: snapshot.delivery,
		orders: snapshot.orders ?? []
	}),
	resetDemo: () => set({
		settings: DEFAULT_SETTINGS,
		products: DEFAULT_PRODUCTS,
		delivery: DEFAULT_DELIVERY,
		cart: [],
		orders: []
	})
}), {
	name: "my-simple-store",
	skipHydration: true,
	partialize: (s) => ({
		settings: s.settings,
		products: s.products,
		delivery: s.delivery,
		cart: s.cart,
		orders: s.orders
	})
}));
function ShopProvider({ children }) {
	(0, import_react.useEffect)(() => {
		useShop.persist.rehydrate();
	}, []);
	return children;
}
var styles_default = "/assets/styles-DeSe94q5.css";
var APP_NAME = "My Simple Store";
var Route$7 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: APP_NAME },
			{
				name: "theme-color",
				content: "#5b21b6"
			},
			{
				name: "description",
				content: "Launch your own branded online store in minutes. No monthly fees. Built for small sellers."
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Figtree:ital,wght@0,400;0,500;0,600;0,700&family=Fraunces:ital,opsz,wght@0,9..144,500;0,9..144,600;1,9..144,500&display=swap"
			}
		]
	}),
	component: RootDocument
});
function RootDocument() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		className: "antialiased",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", {
			className: "min-h-screen bg-bg text-fg",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShopProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
					position: "top-center",
					richColors: true
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
			]
		})]
	});
}
var $$splitComponentImporter$6 = () => import("./routes-BR2DHed6.mjs");
var Route$6 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$6, "component") });
var $$splitComponentImporter$5 = () => import("./admin-CBwR0FGR.mjs");
var Route$5 = createFileRoute("/admin")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("./checkout-C5RCFy-Q.mjs");
var Route$4 = createFileRoute("/checkout")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./evaluate-B6m6WPfj.mjs");
var Route$3 = createFileRoute("/evaluate")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./shop-Wi3QmHL5.mjs");
var Route$2 = createFileRoute("/shop")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./shop-tn6MrlO3.mjs");
var Route$1 = createFileRoute("/shop/")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("../_productId-DI6MrBRd.mjs");
var Route = createFileRoute("/shop/$productId")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var IndexRoute = Route$6.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$7
});
var AdminRoute = Route$5.update({
	id: "/admin",
	path: "/admin",
	getParentRoute: () => Route$7
});
var CheckoutRoute = Route$4.update({
	id: "/checkout",
	path: "/checkout",
	getParentRoute: () => Route$7
});
var EvaluateRoute = Route$3.update({
	id: "/evaluate",
	path: "/evaluate",
	getParentRoute: () => Route$7
});
var ShopRoute = Route$2.update({
	id: "/shop",
	path: "/shop",
	getParentRoute: () => Route$7
});
var ShopIndexRoute = Route$1.update({
	id: "/",
	path: "/",
	getParentRoute: () => ShopRoute
});
var ShopRouteChildren = {
	ShopProductIdRoute: Route.update({
		id: "/$productId",
		path: "/$productId",
		getParentRoute: () => ShopRoute
	}),
	ShopIndexRoute
};
var rootRouteChildren = {
	IndexRoute,
	AdminRoute,
	CheckoutRoute,
	EvaluateRoute,
	ShopRoute: ShopRoute._addFileChildren(ShopRouteChildren)
};
var routeTree = Route$7._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { cartSubtotal as a, digitsOnly as c, cartLines as i, formatMoney as l, Route as n, useShop as o, cartCount as r, CATEGORIES as s, router_exports as t };
