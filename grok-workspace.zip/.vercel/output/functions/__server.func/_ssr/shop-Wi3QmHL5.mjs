import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { g as Outlet } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as StoreShell } from "./store-shell-B4L6LZBj.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/shop-Wi3QmHL5.js
var import_jsx_runtime = require_jsx_runtime();
function ShopLayout() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StoreShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) });
}
//#endregion
export { ShopLayout as component };
