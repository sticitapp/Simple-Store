import { chromium } from "playwright";
import { pathToFileURL } from "node:url";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const root = dirname(fileURLToPath(import.meta.url));

const browser = await chromium.launch({ args: ["--font-render-hinting=none"] });

async function shot(file, width, height, out, scale = 1) {
  const page = await browser.newPage({
    viewport: { width, height },
    deviceScaleFactor: scale,
  });
  await page.goto(pathToFileURL(join(root, file)).href, { waitUntil: "load" });
  await page.evaluate(() => document.fonts.ready);
  await page.waitForTimeout(80);
  await page.screenshot({ path: out, type: "png", omitBackground: false });
  await page.close();
}

await shot("og-card.html", 1200, 630, join(root, "og-raw.png"), 2);
await shot("icon-raster.html", 512, 512, join(root, "icon-512-raw.png"), 1);

const page192 = await browser.newPage({
  viewport: { width: 192, height: 192 },
  deviceScaleFactor: 1,
});
await page192.goto(pathToFileURL(join(root, "icon-raster.html")).href, { waitUntil: "load" });
await page192.screenshot({ path: join(root, "icon-192-raw.png"), type: "png" });
await page192.close();

await browser.close();
console.log("rendered");
