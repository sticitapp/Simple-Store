import { chromium } from "playwright";
import { pathToFileURL } from "node:url";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const root = dirname(fileURLToPath(import.meta.url));
const browser = await chromium.launch({ args: ["--font-render-hinting=none"] });
const html = pathToFileURL(join(root, "icon-raster.html")).href;
const favicon = pathToFileURL(join(root, "favicon-preview.html")).href;

async function shot(url, width, height, out) {
  const page = await browser.newPage({
    viewport: { width, height },
    deviceScaleFactor: 1,
  });
  await page.goto(url, { waitUntil: "load" });
  await page.screenshot({ path: out, type: "png", omitBackground: false });
  await page.close();
}

await shot(html, 512, 512, join(root, "icon-512.staged.png"));
await shot(html, 192, 192, join(root, "icon-192.staged.png"));
await shot(html, 180, 180, join(root, "icon-180.staged.png"));
await shot(favicon, 32, 32, join(root, "favicon-32.png"));
await shot(favicon, 16, 16, join(root, "favicon-16.png"));

await browser.close();
console.log("rendered");
