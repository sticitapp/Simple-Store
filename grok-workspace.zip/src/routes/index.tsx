import { createFileRoute, Link } from "@tanstack/react-router";
import {
  ArrowRight,
  Banknote,
  Check,
  Download,
  MessageCircle,
  Package,
  Palette,
  ScanSearch,
  Smartphone,
  Truck,
} from "lucide-react";
import { ProductCard } from "@/components/product-card";
import { Button } from "@/components/ui/button";
import { useShop } from "@/store/shop-store";

export const Route = createFileRoute("/")({ component: Landing });

const FEATURES = [
  {
    icon: Palette,
    title: "Your brand, your logo",
    body: "Change the store name, logo and colour in seconds. Make it look like your own business.",
  },
  {
    icon: Package,
    title: "Fifty product slots",
    body: "Add photos, prices and descriptions. Edit or remove them whenever you like.",
  },
  {
    icon: Banknote,
    title: "Paid into your bank",
    body: "Buyers pay you by EFT. You keep all of the money — no platform cut.",
  },
  {
    icon: MessageCircle,
    title: "WhatsApp orders",
    body: "A floating button and a ready-made order message, so people can buy in one tap.",
  },
  {
    icon: Truck,
    title: "Delivery options",
    body: "Add collection, courier and locker prices. The total updates at checkout.",
  },
  {
    icon: ScanSearch,
    title: "Product evaluator",
    body: "Score anything for resale before you stock it. Know what is worth buying.",
  },
  {
    icon: Smartphone,
    title: "Installs like an app",
    body: "Add it to a phone home screen. It works on computer and phone.",
  },
  {
    icon: Download,
    title: "Backup and restore",
    body: "Download your full store anytime. Never lose products or settings.",
  },
];

const FAQS = [
  {
    q: "Do I need technical skills?",
    a: "No. Change the name, logo, products and bank details from the Admin panel. Everything is point and click.",
  },
  {
    q: "How do customers pay me?",
    a: "They see your bank details at checkout and pay by EFT. They can also send the order on WhatsApp.",
  },
  {
    q: "What happens after I pay?",
    a: "The seller sends you a private access code. Open Unlock, paste it once, and Admin plus the evaluator stay open on that phone or computer.",
  },
  {
    q: "Can I run more than one store?",
    a: "Yes. Reset or restore a backup to run a different brand. Each copy keeps its own products.",
  },
];

function Landing() {
  const settings = useShop((s) => s.settings);
  const products = useShop((s) => s.products);
  const featured = products.filter((p) => p.featured).slice(0, 4);
  const mosaic = (featured.length >= 4 ? featured : products)
    .slice(0, 4)
    .map((p) => p.image);
  const storeName = settings.name.trim() || "My Simple Store";

  return (
    <div className="min-h-screen bg-bg text-fg">
      {settings.announcement ? (
        <p className="bg-accent px-4 py-2 text-center text-xs font-medium tracking-wide text-accent-fg">
          {settings.announcement}
        </p>
      ) : null}
      <nav className="sticky top-0 z-40 flex items-center justify-between border-b border-border bg-bg/90 px-4 py-3 backdrop-blur-md">
        <Link to="/" className="flex min-w-0 items-center gap-2.5">
          {settings.logo ? (
            <img
              src={settings.logo}
              alt=""
              className="size-8 rounded-sm object-cover outline-none"
            />
          ) : (
            <span className="flex size-8 items-center justify-center rounded-sm bg-primary font-display text-sm text-primary-fg">
              {storeName.slice(0, 1)}
            </span>
          )}
          <span className="truncate font-display text-lg font-medium tracking-tight">
            {storeName}
          </span>
        </Link>
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="sm" asChild className="hidden sm:inline-flex">
            <Link to="/evaluate">Evaluator</Link>
          </Button>
          <Button asChild size="sm">
            <Link to="/shop">
              Shop
              <ArrowRight />
            </Link>
          </Button>
        </div>
      </nav>

      <section className="bg-primary text-primary-fg">
        <div className="mx-auto grid max-w-6xl items-center gap-10 px-4 py-14 md:grid-cols-2 md:py-20">
          <div className="stagger-in">
            <p className="text-sm font-medium text-primary-fg/80">
              {settings.tagline || "Your own online store"}
            </p>
            <h1 className="mt-3 font-display text-4xl font-medium tracking-tight md:text-5xl">
              {storeName}
            </h1>
            <p className="mt-4 max-w-md text-primary-fg/85">
              Shop the latest pieces, pay by EFT, or send the order on WhatsApp.
              Packed with care — no monthly platform fees.
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <Button
                size="lg"
                className="bg-surface text-fg hover:opacity-95"
                asChild
              >
                <Link to="/shop">
                  Shop now
                  <ArrowRight />
                </Link>
              </Button>
              <Button
                size="lg"
                className="border border-primary-fg/30 bg-transparent text-primary-fg hover:bg-primary-fg/10"
                asChild
              >
                <Link to="/admin">Edit store</Link>
              </Button>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            {mosaic.map((src, i) => (
              <img
                key={`${src}-${i}`}
                src={src}
                alt=""
                className={`aspect-square w-full rounded-xl object-cover outline-none ${
                  i % 2 === 1 ? "mt-6" : ""
                }`}
              />
            ))}
          </div>
        </div>
      </section>

      {featured.length > 0 ? (
        <section className="mx-auto max-w-6xl px-4 py-16">
          <div className="mb-8 flex items-end justify-between gap-4">
            <div>
              <p className="text-sm font-medium text-primary">In the shop</p>
              <h2 className="mt-1 font-display text-3xl font-medium">Featured</h2>
            </div>
            <Button variant="ghost" asChild>
              <Link to="/shop">
                All products
                <ArrowRight />
              </Link>
            </Button>
          </div>
          <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
            {featured.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </section>
      ) : null}

      <section className="mx-auto max-w-6xl px-4 py-16">
        <h2 className="text-center font-display text-3xl font-medium">
          Everything you need to start selling
        </h2>
        <p className="mx-auto mt-2 max-w-lg text-center text-muted">
          Built for people who just want to sell products without expensive platforms.
        </p>
        <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {FEATURES.map((f) => (
            <article
              key={f.title}
              className="rounded-xl bg-surface p-5 shadow-[var(--shadow-border)]"
            >
              <span className="flex size-10 items-center justify-center rounded-md bg-primary/10">
                <f.icon className="size-5 text-primary" />
              </span>
              <h3 className="mt-3 font-medium">{f.title}</h3>
              <p className="mt-1 text-sm text-muted">{f.body}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-16">
        <h2 className="text-center font-display text-3xl font-medium">
          Why people choose it
        </h2>
        <p className="mx-auto mt-2 max-w-lg text-center text-muted">
          Stop paying monthly fees for features you do not need.
        </p>
        <div className="mt-10 overflow-x-auto rounded-xl bg-surface shadow-[var(--shadow-border)]">
          <table className="w-full min-w-[640px] text-left text-sm">
            <thead className="bg-primary text-primary-fg">
              <tr>
                <th className="px-4 py-3 font-medium">Feature</th>
                <th className="px-4 py-3 font-medium">Shopify</th>
                <th className="px-4 py-3 font-medium">WooCommerce</th>
                <th className="px-4 py-3 font-medium">{storeName}</th>
              </tr>
            </thead>
            <tbody>
              {[
                ["Monthly cost", "$29–$299+", "Hosting + plugins", "$0 after purchase"],
                ["Setup", "Medium", "Hard", "Very easy"],
                ["Your branding", "Yes", "Yes", "Yes"],
                ["Bank transfer checkout", "Extra fees", "Plugins", "Built in"],
                ["WhatsApp ordering", "Paid apps", "Plugins", "Built in"],
                ["Product resale score", "No", "No", "Included"],
                ["One-time price", "No", "No", "Only $30"],
              ].map((row) => (
                <tr key={row[0]} className="border-t border-border">
                  {row.map((cell, i) => (
                    <td
                      key={i}
                      className={`px-4 py-3 ${i === 3 ? "font-medium text-primary" : ""}`}
                    >
                      {cell}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <section id="buy" className="mx-auto max-w-6xl px-4 py-16">
        <h2 className="text-center font-display text-3xl font-medium">
          Simple pricing
        </h2>
        <p className="mt-2 text-center text-muted">Pay once. Use forever.</p>
        <div className="mx-auto mt-10 max-w-md rounded-xl bg-surface p-8 text-center shadow-[var(--shadow-border)]">
          <p className="text-sm font-medium uppercase tracking-wide text-primary">
            Lifetime access
          </p>
          <p className="mt-2 font-display text-5xl font-medium text-primary">$30</p>
          <p className="mt-1 text-sm text-muted">One-time · no monthly fees</p>
          <ul className="mx-auto mt-6 max-w-xs space-y-2 text-left text-sm">
            {[
              "Full store (installable)",
              "50 product slots",
              "Custom logo and branding",
              "Bank transfer checkout",
              "WhatsApp order button",
              "Delivery options",
              "Product resale evaluator",
              "Backup and restore",
            ].map((item) => (
              <li key={item} className="flex items-center gap-2">
                <Check className="size-4 text-success" />
                {item}
              </li>
            ))}
          </ul>
          <Button size="lg" className="mt-8 w-full" asChild>
            <Link to="/unlock">
              I already paid — unlock
              <ArrowRight />
            </Link>
          </Button>
          <p className="mt-3 text-xs text-muted">
            After you pay, the seller sends you an access code. Enter it once on
            this device.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-3xl px-4 py-16">
        <h2 className="text-center font-display text-3xl font-medium">
          Questions
        </h2>
        <div className="mt-8 space-y-3">
          {FAQS.map((item) => (
            <article
              key={item.q}
              className="rounded-lg bg-surface px-5 py-4 shadow-[var(--shadow-border)]"
            >
              <h3 className="font-medium">{item.q}</h3>
              <p className="mt-1 text-sm text-muted">{item.a}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="bg-primary px-4 py-16 text-center text-primary-fg">
        <h2 className="font-display text-3xl font-medium">
          Shop {storeName}
        </h2>
        <p className="mx-auto mt-2 max-w-md text-primary-fg/85">
          Browse the catalogue, add to your bag, and check out by EFT or WhatsApp.
        </p>
        <Button
          size="lg"
          className="mt-8 bg-surface text-fg hover:opacity-95"
          asChild
        >
          <Link to="/shop">
            Open the shop
            <ArrowRight />
          </Link>
        </Button>
      </section>

      <footer className="px-4 py-8 text-center text-sm text-muted">
        © {new Date().getFullYear()} {storeName}
      </footer>
    </div>
  );
}
