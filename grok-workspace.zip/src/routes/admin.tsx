import { useRef, useState, type ReactNode } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { toast } from "sonner";
import { Plus, Trash2 } from "lucide-react";
import { StoreShell } from "@/components/store-shell";
import { RequirePaid } from "@/components/paywall";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { downloadJson, readFileAsDataUrl } from "@/lib/utils";
import { formatMoney } from "@/lib/format";
import { useShop } from "@/store/shop-store";
import { useAccess } from "@/store/access-store";
import { ACCESS } from "@/lib/access";
import { MAX_PRODUCTS, type Product, type ShopSnapshot } from "@/store/types";

export const Route = createFileRoute("/admin")({
  component: AdminPage,
});

function AdminPage() {
  return (
    <StoreShell>
      <RequirePaid next="/admin">
        <AdminInner />
      </RequirePaid>
    </StoreShell>
  );
}

function AdminInner() {
  return (
    <>
      <h1 className="font-display text-3xl font-medium">Admin</h1>
      <p className="mt-1 text-sm text-muted">
        This is your store. Change anything — it saves on this device.
      </p>
      <Tabs defaultValue="brand" className="mt-8">
        <TabsList>
          <TabsTrigger value="brand">Brand</TabsTrigger>
          <TabsTrigger value="products">Products</TabsTrigger>
          <TabsTrigger value="delivery">Delivery</TabsTrigger>
          <TabsTrigger value="bank">Bank</TabsTrigger>
          <TabsTrigger value="orders">Orders</TabsTrigger>
          <TabsTrigger value="backup">Backup</TabsTrigger>
          <TabsTrigger value="access">Access</TabsTrigger>
        </TabsList>
        <TabsContent value="brand">
          <BrandPanel />
        </TabsContent>
        <TabsContent value="products">
          <ProductsPanel />
        </TabsContent>
        <TabsContent value="delivery">
          <DeliveryPanel />
        </TabsContent>
        <TabsContent value="bank">
          <BankPanel />
        </TabsContent>
        <TabsContent value="orders">
          <OrdersPanel />
        </TabsContent>
        <TabsContent value="backup">
          <BackupPanel />
        </TabsContent>
        <TabsContent value="access">
          <AccessPanel />
        </TabsContent>
      </Tabs>
    </>
  );
}

function Field({
  label,
  children,
}: {
  label: string;
  children: ReactNode;
}) {
  return (
    <div className="space-y-1.5">
      <Label>{label}</Label>
      {children}
    </div>
  );
}

function BrandPanel() {
  const settings = useShop((s) => s.settings);
  const updateSettings = useShop((s) => s.updateSettings);

  async function onLogo(file: File | undefined) {
    if (!file) return;
    const data = await readFileAsDataUrl(file);
    updateSettings({ logo: data });
  }

  return (
    <div className="max-w-xl space-y-4">
      <Field label="Store name">
        <Input
          value={settings.name}
          onChange={(e) => updateSettings({ name: e.target.value })}
        />
      </Field>
      <Field label="Tagline">
        <Input
          value={settings.tagline}
          onChange={(e) => updateSettings({ tagline: e.target.value })}
        />
      </Field>
      <Field label="Announcement bar">
        <Input
          value={settings.announcement}
          onChange={(e) => updateSettings({ announcement: e.target.value })}
        />
      </Field>
      <Field label="WhatsApp number (with country code)">
        <Input
          value={settings.whatsapp}
          onChange={(e) => updateSettings({ whatsapp: e.target.value })}
        />
      </Field>
      <Field label="Currency">
        <Input
          value={settings.currency}
          onChange={(e) =>
            updateSettings({ currency: e.target.value.toUpperCase() })
          }
        />
      </Field>
      <Field label="Brand colour">
        <input
          type="color"
          value={settings.primaryColor}
          onChange={(e) => updateSettings({ primaryColor: e.target.value })}
          className="h-11 w-20 cursor-pointer rounded-md border border-border bg-surface"
        />
      </Field>
      <Field label="Logo">
        <Input
          type="file"
          accept="image/*"
          onChange={(e) => void onLogo(e.target.files?.[0])}
        />
      </Field>
      {settings.logo ? (
        <img src={settings.logo} alt="" className="size-16 rounded-md object-cover" />
      ) : null}
    </div>
  );
}

function ProductsPanel() {
  const products = useShop((s) => s.products);
  const addProduct = useShop((s) => s.addProduct);
  const updateProduct = useShop((s) => s.updateProduct);
  const removeProduct = useShop((s) => s.removeProduct);
  const currency = useShop((s) => s.settings.currency);
  const [editing, setEditing] = useState<Product | null>(null);

  function startNew() {
    if (products.length >= MAX_PRODUCTS) {
      toast.error(`Maximum ${MAX_PRODUCTS} products`);
      return;
    }
    setEditing({
      id:
        typeof crypto !== "undefined" && crypto.randomUUID
          ? crypto.randomUUID()
          : `${Date.now()}`,
      name: "",
      description: "",
      price: 0,
      image: "/products/candle.jpg",
      category: "Home",
      stock: 10,
      featured: false,
    });
  }

  function save(product: Product) {
    const exists = products.some((p) => p.id === product.id);
    if (exists) updateProduct(product.id, product);
    else {
      const ok = addProduct(product);
      if (!ok) {
        toast.error(`Maximum ${MAX_PRODUCTS} products`);
        return;
      }
    }
    setEditing(null);
    toast.success("Product saved");
  }

  return (
    <div>
      <div className="mb-4 flex items-center justify-between">
        <p className="text-sm text-muted">
          {products.length} / {MAX_PRODUCTS} slots
        </p>
        <Button onClick={startNew}>
          <Plus />
          Add product
        </Button>
      </div>
      {editing ? (
        <ProductEditor
          product={editing}
          onCancel={() => setEditing(null)}
          onSave={save}
        />
      ) : null}
      <ul className="mt-4 divide-y divide-border rounded-xl bg-surface shadow-[var(--shadow-border)]">
        {products.map((p) => (
          <li key={p.id} className="flex items-center gap-3 p-3">
            <img src={p.image} alt="" className="size-14 rounded-md object-cover" />
            <div className="min-w-0 flex-1">
              <p className="truncate font-medium">{p.name}</p>
              <p className="text-sm text-muted">
                {formatMoney(p.price, currency)} · {p.stock} in stock
              </p>
            </div>
            <Button size="sm" variant="ghost" onClick={() => setEditing(p)}>
              Edit
            </Button>
            <Button
              size="icon"
              variant="ghost"
              aria-label={`Delete ${p.name}`}
              onClick={() => removeProduct(p.id)}
            >
              <Trash2 />
            </Button>
          </li>
        ))}
      </ul>
    </div>
  );
}

function ProductEditor({
  product,
  onCancel,
  onSave,
}: {
  product: Product;
  onCancel: () => void;
  onSave: (p: Product) => void;
}) {
  const [draft, setDraft] = useState(product);

  async function onImage(file: File | undefined) {
    if (!file) return;
    const data = await readFileAsDataUrl(file);
    setDraft((d) => ({ ...d, image: data }));
  }

  return (
    <div className="mb-6 space-y-3 rounded-xl bg-surface p-5 shadow-[var(--shadow-border)]">
      <Field label="Name">
        <Input
          value={draft.name}
          onChange={(e) => setDraft((d) => ({ ...d, name: e.target.value }))}
        />
      </Field>
      <Field label="Description">
        <Textarea
          value={draft.description}
          onChange={(e) =>
            setDraft((d) => ({ ...d, description: e.target.value }))
          }
        />
      </Field>
      <div className="grid gap-3 sm:grid-cols-3">
        <Field label="Price">
          <Input
            type="number"
            min={0}
            value={draft.price}
            onChange={(e) =>
              setDraft((d) => ({ ...d, price: Number(e.target.value) || 0 }))
            }
          />
        </Field>
        <Field label="Stock">
          <Input
            type="number"
            min={0}
            value={draft.stock}
            onChange={(e) =>
              setDraft((d) => ({ ...d, stock: Number(e.target.value) || 0 }))
            }
          />
        </Field>
        <Field label="Category">
          <Input
            value={draft.category}
            onChange={(e) =>
              setDraft((d) => ({ ...d, category: e.target.value }))
            }
          />
        </Field>
      </div>
      <Field label="Photo">
        <Input
          type="file"
          accept="image/*"
          onChange={(e) => void onImage(e.target.files?.[0])}
        />
      </Field>
      <label className="flex items-center gap-2 text-sm">
        <input
          type="checkbox"
          checked={draft.featured}
          onChange={(e) =>
            setDraft((d) => ({ ...d, featured: e.target.checked }))
          }
        />
        Featured on the shop home
      </label>
      <div className="flex gap-2">
        <Button type="button" onClick={() => onSave(draft)}>
          Save
        </Button>
        <Button type="button" variant="ghost" onClick={onCancel}>
          Cancel
        </Button>
      </div>
    </div>
  );
}

function DeliveryPanel() {
  const delivery = useShop((s) => s.delivery);
  const addDelivery = useShop((s) => s.addDelivery);
  const updateDelivery = useShop((s) => s.updateDelivery);
  const removeDelivery = useShop((s) => s.removeDelivery);
  const currency = useShop((s) => s.settings.currency);

  return (
    <div className="space-y-4">
      {delivery.map((d) => (
        <div
          key={d.id}
          className="grid gap-3 rounded-xl bg-surface p-4 shadow-[var(--shadow-border)] sm:grid-cols-2"
        >
          <Field label="Name">
            <Input
              value={d.name}
              onChange={(e) => updateDelivery(d.id, { name: e.target.value })}
            />
          </Field>
          <Field label={`Price (${currency})`}>
            <Input
              type="number"
              min={0}
              value={d.price}
              onChange={(e) =>
                updateDelivery(d.id, { price: Number(e.target.value) || 0 })
              }
            />
          </Field>
          <Field label="Description">
            <Input
              value={d.description}
              onChange={(e) =>
                updateDelivery(d.id, { description: e.target.value })
              }
            />
          </Field>
          <Field label="Time">
            <Input
              value={d.eta}
              onChange={(e) => updateDelivery(d.id, { eta: e.target.value })}
            />
          </Field>
          <Button
            variant="ghost"
            size="sm"
            className="text-danger"
            onClick={() => removeDelivery(d.id)}
          >
            <Trash2 />
            Remove
          </Button>
        </div>
      ))}
      <Button
        variant="secondary"
        onClick={() =>
          addDelivery({
            id:
              typeof crypto !== "undefined" && crypto.randomUUID
                ? crypto.randomUUID()
                : `${Date.now()}`,
            name: "New option",
            description: "",
            price: 0,
            eta: "2–4 days",
          })
        }
      >
        <Plus />
        Add delivery option
      </Button>
    </div>
  );
}

function BankPanel() {
  const bank = useShop((s) => s.settings.bank);
  const updateBank = useShop((s) => s.updateBank);
  return (
    <div className="max-w-xl space-y-4">
      {(
        [
          ["accountName", "Account name"],
          ["bankName", "Bank"],
          ["accountNumber", "Account number"],
          ["branchCode", "Branch code"],
          ["accountType", "Account type"],
        ] as const
      ).map(([key, label]) => (
        <Field key={key} label={label}>
          <Input
            value={bank[key]}
            onChange={(e) => updateBank({ [key]: e.target.value })}
          />
        </Field>
      ))}
    </div>
  );
}

function OrdersPanel() {
  const orders = useShop((s) => s.orders);
  const currency = useShop((s) => s.settings.currency);
  if (orders.length === 0) {
    return (
      <p className="text-sm text-muted">
        No orders yet. Place a test order from the shop to see it here.
      </p>
    );
  }
  return (
    <ul className="space-y-3">
      {orders.map((o) => (
        <li
          key={o.id}
          className="rounded-xl bg-surface p-4 text-sm shadow-[var(--shadow-border)]"
        >
          <div className="flex justify-between gap-3">
            <p className="font-medium">{o.reference}</p>
            <p className="tabular-nums">
              {formatMoney(o.total, currency)}
            </p>
          </div>
          <p className="mt-1 text-muted">
            {o.customerName} · {o.phone}
          </p>
          <p className="mt-1 text-muted">
            {o.items.map((i) => `${i.qty}× ${i.name}`).join(", ")}
          </p>
        </li>
      ))}
    </ul>
  );
}

function BackupPanel() {
  const settings = useShop((s) => s.settings);
  const products = useShop((s) => s.products);
  const delivery = useShop((s) => s.delivery);
  const orders = useShop((s) => s.orders);
  const restore = useShop((s) => s.restore);
  const resetDemo = useShop((s) => s.resetDemo);
  const fileRef = useRef<HTMLInputElement>(null);

  function onBackup() {
    downloadJson(`my-simple-store-${new Date().toISOString().slice(0, 10)}.json`, {
      settings,
      products,
      delivery,
      orders,
    } satisfies ShopSnapshot);
    toast.success("Backup downloaded");
  }

  async function onRestore(file: File | undefined) {
    if (!file) return;
    try {
      const text = await file.text();
      const data = JSON.parse(text) as ShopSnapshot;
      if (!data.settings || !Array.isArray(data.products)) {
        throw new Error("Not a store backup");
      }
      restore({
        settings: data.settings,
        products: data.products,
        delivery: data.delivery ?? [],
        orders: data.orders ?? [],
      });
      toast.success("Store restored");
    } catch {
      toast.error("Could not read that file");
    }
  }

  return (
    <div className="max-w-xl space-y-4">
      <p className="text-sm text-muted">
        Download a copy of your store, or restore one. Reset returns the demo
        products.
      </p>
      <div className="flex flex-wrap gap-2">
        <Button onClick={onBackup}>Download backup</Button>
        <Button variant="secondary" onClick={() => fileRef.current?.click()}>
          Restore backup
        </Button>
        <Button
          variant="ghost"
          className="text-danger"
          onClick={() => {
            resetDemo();
            toast.success("Demo store restored");
          }}
        >
          Reset demo
        </Button>
      </div>
      <input
        ref={fileRef}
        type="file"
        accept="application/json"
        className="hidden"
        onChange={(e) => void onRestore(e.target.files?.[0])}
      />
    </div>
  );
}

function AccessPanel() {
  const lock = useAccess((s) => s.lock);

  return (
    <div className="max-w-xl space-y-4">
      <p className="text-sm text-muted">
        This device is unlocked. Visitors still need to pay, then enter the
        access code you send them. Do not publish the code on the landing page.
      </p>
      <div className="rounded-xl bg-surface p-4 text-sm shadow-[var(--shadow-border)]">
        <p className="font-medium">How to sell access</p>
        <ol className="mt-2 list-decimal space-y-1 pl-5 text-muted">
          <li>Buyer pays {ACCESS.priceLabel} (PayFast, PayPal or Gumroad).</li>
          <li>You send them the lifetime access code privately (WhatsApp is fine).</li>
          <li>They open Unlock, paste it once. That browser stays unlocked.</li>
        </ol>
        <p className="mt-3 font-medium text-fg">
          Same code for every paying customer. Do not post it on the public page.
        </p>
        <p className="mt-3 text-muted">
          {ACCESS.paymentUrl
            ? "The Buy button on the unlock page goes to your payment link."
            : "The Buy button is not linked yet. Send a PayFast, PayPal or Gumroad checkout URL and it can be attached so every visitor pays first."}
        </p>
      </div>
      <Button
        variant="secondary"
        onClick={() => {
          lock();
          toast.success("This device is locked. Enter the code to get back in.");
        }}
      >
        Lock this device to test
      </Button>
    </div>
  );
}
