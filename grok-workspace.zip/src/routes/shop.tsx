import { Outlet, createFileRoute } from "@tanstack/react-router";
import { StoreShell } from "@/components/store-shell";

export const Route = createFileRoute("/shop")({
  component: ShopLayout,
});

function ShopLayout() {
  return (
    <StoreShell>
      <Outlet />
    </StoreShell>
  );
}
