import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { StoreShell } from "@/components/store-shell";
import { RequirePaid } from "@/components/paywall";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  evaluateProduct,
  type DemandLevel,
  type EvalInput,
  type ShipEase,
  type TrendKind,
} from "@/lib/evaluator";
import { formatMoney } from "@/lib/format";
import { cn } from "@/lib/utils";
import { useShop } from "@/store/shop-store";

export const Route = createFileRoute("/evaluate")({
  component: EvaluatePage,
});

function EvaluatePage() {
  return (
    <StoreShell>
      <RequirePaid next="/evaluate">
        <EvaluateInner />
      </RequirePaid>
    </StoreShell>
  );
}

const DEMAND: { id: DemandLevel; label: string }[] = [
  { id: "low", label: "Low" },
  { id: "medium", label: "Medium" },
  { id: "high", label: "High" },
];

function EvaluateInner() {
  const currency = useShop((s) => s.settings.currency);
  const [input, setInput] = useState<EvalInput>({
    name: "",
    cost: 80,
    sell: 185,
    demand: "medium",
    competition: "medium",
    shipping: "easy",
    uniqueness: "medium",
    trend: "evergreen",
    fragility: false,
  });

  const result = useMemo(() => evaluateProduct(input), [input]);

  return (
    <div className="grid gap-8 lg:grid-cols-[1fr_340px]">
      <div>
        <p className="text-sm font-medium text-primary">Before you stock it</p>
        <h1 className="mt-1 font-display text-3xl font-medium">
          Product evaluator
        </h1>
        <p className="mt-2 max-w-xl text-muted">
          Score a product for resale. Honest numbers beat a pretty photo — this
          is the tool included with My Simple Store.
        </p>

        <div className="mt-8 space-y-5">
          <div className="space-y-1.5">
            <Label htmlFor="eval-name">Product name</Label>
            <Input
              id="eval-name"
              placeholder="Amber cedar candle"
              value={input.name}
              onChange={(e) => setInput((s) => ({ ...s, name: e.target.value }))}
            />
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label htmlFor="eval-cost">Your cost</Label>
              <Input
                id="eval-cost"
                type="number"
                min={0}
                value={input.cost}
                onChange={(e) =>
                  setInput((s) => ({ ...s, cost: Number(e.target.value) || 0 }))
                }
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="eval-sell">Selling price</Label>
              <Input
                id="eval-sell"
                type="number"
                min={0}
                value={input.sell}
                onChange={(e) =>
                  setInput((s) => ({ ...s, sell: Number(e.target.value) || 0 }))
                }
              />
            </div>
          </div>
          <Choice
            label="Customer demand"
            value={input.demand}
            options={DEMAND}
            onChange={(demand) => setInput((s) => ({ ...s, demand }))}
          />
          <Choice
            label="Competition"
            value={input.competition}
            options={DEMAND}
            onChange={(competition) => setInput((s) => ({ ...s, competition }))}
          />
          <Choice
            label="How hard to ship"
            value={input.shipping}
            options={[
              { id: "easy", label: "Easy" },
              { id: "typical", label: "Typical" },
              { id: "hard", label: "Hard" },
            ]}
            onChange={(shipping) => setInput((s) => ({ ...s, shipping }))}
          />
          <Choice
            label="How unique"
            value={input.uniqueness}
            options={DEMAND}
            onChange={(uniqueness) => setInput((s) => ({ ...s, uniqueness }))}
          />
          <Choice
            label="Trend"
            value={input.trend}
            options={[
              { id: "evergreen", label: "Evergreen" },
              { id: "seasonal", label: "Seasonal" },
              { id: "fad", label: "Fad" },
            ]}
            onChange={(trend) => setInput((s) => ({ ...s, trend }))}
          />
          <label className="flex items-center gap-2 text-sm">
            <input
              type="checkbox"
              checked={input.fragility}
              onChange={(e) =>
                setInput((s) => ({ ...s, fragility: e.target.checked }))
              }
            />
            Fragile — extra packing or breakage risk
          </label>
        </div>
      </div>

      <aside className="h-fit rounded-xl bg-surface p-6 shadow-[var(--shadow-border)]">
        <p className="text-sm text-muted">Resale score</p>
        <p className="mt-1 font-display text-5xl font-medium tabular-nums">
          {result.score}
          <span className="ml-2 text-2xl text-muted">{result.grade}</span>
        </p>
        <p className="mt-3 text-sm">{result.verdict}</p>
        <p className="mt-2 text-sm text-muted">
          {formatMoney(input.cost, currency)} in ·{" "}
          {formatMoney(input.sell, currency)} out · {result.marginLabel}
        </p>
        <ul className="mt-5 space-y-3">
          {result.reasons.map((r) => (
            <li key={r.label} className="text-sm">
              <p
                className={cn(
                  "font-medium",
                  r.tone === "good" && "text-success",
                  r.tone === "warn" && "text-accent",
                  r.tone === "bad" && "text-danger",
                )}
              >
                {r.label}
              </p>
              <p className="text-muted">{r.detail}</p>
            </li>
          ))}
        </ul>
      </aside>
    </div>
  );
}

function Choice<T extends string>({
  label,
  value,
  options,
  onChange,
}: {
  label: string;
  value: T;
  options: { id: T; label: string }[];
  onChange: (value: T) => void;
}) {
  return (
    <fieldset>
      <legend className="mb-2 text-sm font-medium">{label}</legend>
      <div className="flex flex-wrap gap-1">
        {options.map((o) => (
          <Button
            key={o.id}
            type="button"
            size="sm"
            variant={value === o.id ? "default" : "outline"}
            onClick={() => onChange(o.id)}
          >
            {o.label}
          </Button>
        ))}
      </div>
    </fieldset>
  );
}
