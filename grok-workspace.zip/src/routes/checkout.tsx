import { FormEvent, useMemo, useState, type ReactNode } from "react";
import { Link, createFileRoute } from "@tanstack/react-router";
import { MessageCircle } from "lucide-react";
import { StoreShell } from "@/components/store-shell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { formatMoney } from "@/lib/format";
import { orderMessage, waLink } from "@/lib/whatsapp";
import { cartLines, cartSubtotal, useShop } from "@/store/shop-store";
import type { PlacedOrder } from "@/store/types";

export const Route = createFileRoute("/checkout")({
  component: CheckoutPage,
});

function CheckoutPage() {
  return (
    <StoreShell>
      <CheckoutInner />
    </StoreShell>
  );
}

function CheckoutInner() {
  const cart = useShop((s) => s.cart);
  const products = useShop((s) => s.products);
  const delivery = useShop((s) => s.delivery);
  const settings = useShop((s) => s.settings);
  const placeOrder = useShop((s) => s.placeOrder);
  const lines = cartLines({ cart, products });
  const subtotal = cartSubtotal(lines);

  const [deliveryId, setDeliveryId] = useState(delivery[0]?.id ?? "");
  const [order, setOrder] = useState<PlacedOrder | null>(null);
  const [form, setForm] = useState({
    customerName: "",
    phone: "",
    email: "",
    address: "",
    notes: "",
  });

  const selected = delivery.find((d) => d.id === deliveryId);
  const total = subtotal + (selected?.price ?? 0);

  const waHref = useMemo(() => {
    if (!order) return "";
    return waLink(
      settings.whatsapp,
      orderMessage({
        settings,
        customerName: order.customerName,
        phone: order.phone,
        address: order.address,
        notes: order.notes,
        lines: order.items.map((i) => ({
          productId: i.productId,
          name: i.name,
          price: i.price,
          image: "",
          qty: i.qty,
        })),
        delivery: delivery.find((d) => d.id === order.deliveryId),
        total: order.total,
        reference: order.reference,
      }),
    );
  }, [order, settings, delivery]);

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    const placed = placeOrder({ ...form, deliveryId });
    if (placed) setOrder(placed);
  }

  if (order) {
    const bank = settings.bank;
    return (
      <div className="mx-auto max-w-xl">
        <p className="text-sm font-medium text-success">Order received</p>
        <h1 className="mt-2 font-display text-3xl font-medium">
          Pay by EFT to complete
        </h1>
        <p className="mt-2 text-muted">
          Use reference <span className="font-medium text-fg">{order.reference}</span>{" "}
          so we can match your payment. Total{" "}
          <span className="tabular-nums font-medium text-fg">
            {formatMoney(order.total, settings.currency)}
          </span>
          .
        </p>
        <div className="mt-6 rounded-xl bg-surface p-5 text-sm shadow-[var(--shadow-border)]">
          <p className="font-medium">Bank details</p>
          <dl className="mt-3 space-y-2">
            {[
              ["Account name", bank.accountName],
              ["Bank", bank.bankName],
              ["Account number", bank.accountNumber],
              ["Branch code", bank.branchCode],
              ["Account type", bank.accountType],
              ["Reference", order.reference],
            ].map(([k, v]) => (
              <div key={k} className="flex justify-between gap-4">
                <dt className="text-muted">{k}</dt>
                <dd className="text-right font-medium">{v}</dd>
              </div>
            ))}
          </dl>
        </div>
        <div className="mt-4 flex flex-col gap-2 sm:flex-row">
          {settings.whatsapp ? (
            <Button asChild className="flex-1">
              <a href={waHref} target="_blank" rel="noreferrer">
                <MessageCircle />
                Send order on WhatsApp
              </a>
            </Button>
          ) : null}
          <Button variant="secondary" asChild className="flex-1">
            <Link to="/shop">Continue shopping</Link>
          </Button>
        </div>
      </div>
    );
  }

  if (lines.length === 0) {
    return (
      <div className="py-16 text-center">
        <h1 className="font-display text-3xl font-medium">Your bag is empty</h1>
        <Button asChild className="mt-4">
          <Link to="/shop">Back to shop</Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="grid gap-10 lg:grid-cols-[1fr_320px]">
      <div>
        <h1 className="font-display text-3xl font-medium">Checkout</h1>
        <p className="mt-1 text-sm text-muted">
          Pay by EFT after you place the order. We pack when payment shows.
        </p>
        <form className="mt-8 space-y-4" onSubmit={onSubmit}>
          <Field label="Full name">
            <Input
              required
              value={form.customerName}
              onChange={(e) =>
                setForm((f) => ({ ...f, customerName: e.target.value }))
              }
            />
          </Field>
          <Field label="Phone">
            <Input
              required
              type="tel"
              value={form.phone}
              onChange={(e) => setForm((f) => ({ ...f, phone: e.target.value }))}
            />
          </Field>
          <Field label="Email">
            <Input
              type="email"
              value={form.email}
              onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))}
            />
          </Field>
          <Field label="Delivery address">
            <Textarea
              required
              value={form.address}
              onChange={(e) =>
                setForm((f) => ({ ...f, address: e.target.value }))
              }
            />
          </Field>
          <fieldset>
            <legend className="mb-2 text-sm font-medium">Delivery</legend>
            <div className="space-y-2">
              {delivery.map((d) => (
                <label
                  key={d.id}
                  className="flex cursor-pointer items-start gap-3 rounded-lg bg-surface p-3 shadow-[var(--shadow-border)]"
                >
                  <input
                    type="radio"
                    name="delivery"
                    className="mt-1"
                    checked={deliveryId === d.id}
                    onChange={() => setDeliveryId(d.id)}
                  />
                  <span className="flex-1">
                    <span className="flex justify-between gap-3 text-sm font-medium">
                      {d.name}
                      <span className="tabular-nums">
                        {d.price === 0
                          ? "Free"
                          : formatMoney(d.price, settings.currency)}
                      </span>
                    </span>
                    <span className="block text-xs text-muted">
                      {d.description} · {d.eta}
                    </span>
                  </span>
                </label>
              ))}
            </div>
          </fieldset>
          <Field label="Notes (optional)">
            <Textarea
              value={form.notes}
              onChange={(e) => setForm((f) => ({ ...f, notes: e.target.value }))}
            />
          </Field>
          <Button type="submit" size="lg" className="w-full sm:w-auto">
            Place order · {formatMoney(total, settings.currency)}
          </Button>
        </form>
      </div>
      <aside className="h-fit rounded-xl bg-surface p-5 shadow-[var(--shadow-border)]">
        <h2 className="font-medium">Order</h2>
        <ul className="mt-3 space-y-3">
          {lines.map((l) => (
            <li key={l.productId} className="flex justify-between gap-3 text-sm">
              <span>
                {l.qty}× {l.name}
              </span>
              <span className="tabular-nums">
                {formatMoney(l.price * l.qty, settings.currency)}
              </span>
            </li>
          ))}
        </ul>
        <div className="mt-4 space-y-1 border-t border-border pt-3 text-sm">
          <p className="flex justify-between">
            <span className="text-muted">Subtotal</span>
            <span className="tabular-nums">
              {formatMoney(subtotal, settings.currency)}
            </span>
          </p>
          <p className="flex justify-between">
            <span className="text-muted">Delivery</span>
            <span className="tabular-nums">
              {formatMoney(selected?.price ?? 0, settings.currency)}
            </span>
          </p>
          <p className="flex justify-between font-medium">
            <span>Total</span>
            <span className="tabular-nums">
              {formatMoney(total, settings.currency)}
            </span>
          </p>
        </div>
      </aside>
    </div>
  );
}

function Field({
  label,
  children,
}: {
  label: string;
  children: ReactNode;
}) {
  return (
    <div className="space-y-1.5">
      <Label>{label}</Label>
      {children}
    </div>
  );
}
