import { createFileRoute } from "@tanstack/react-router";
import { Paywall } from "@/components/paywall";
import { StoreShell } from "@/components/store-shell";
import { useAccess } from "@/store/access-store";
import { Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/unlock")({
  component: UnlockPage,
});

function UnlockPage() {
  const unlocked = useAccess((s) => s.unlocked);
  const hydrated = useAccess((s) => s.hydrated);

  return (
    <StoreShell>
      {hydrated && unlocked ? (
        <div className="mx-auto max-w-md py-10 text-center">
          <h1 className="font-display text-3xl font-medium">Already unlocked</h1>
          <p className="mt-2 text-sm text-muted">
            This device has paid access. Admin and the evaluator are open.
          </p>
          <div className="mt-6 flex justify-center gap-2">
            <Button asChild>
              <Link to="/admin">Open admin</Link>
            </Button>
            <Button variant="secondary" asChild>
              <Link to="/evaluate">Evaluator</Link>
            </Button>
          </div>
        </div>
      ) : (
        <Paywall next="/admin" />
      )}
    </StoreShell>
  );
}
