import { Link, createFileRoute } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { formatMoney } from "@/lib/format";
import { useShop } from "@/store/shop-store";

export const Route = createFileRoute("/shop/$productId")({
  component: ProductPage,
});

function ProductPage() {
  const { productId } = Route.useParams();
  const product = useShop((s) => s.products.find((p) => p.id === productId));
  const currency = useShop((s) => s.settings.currency);
  const addToCart = useShop((s) => s.addToCart);

  if (!product) {
    return (
      <div className="py-16 text-center">
        <p className="text-muted">That product is no longer listed.</p>
        <Button asChild className="mt-4">
          <Link to="/shop">Back to shop</Link>
        </Button>
      </div>
    );
  }

  const soldOut = product.stock <= 0;

  return (
    <div>
      <Link
        to="/shop"
        className="mb-6 inline-flex items-center gap-2 text-sm text-muted hover:text-fg"
      >
        <ArrowLeft className="size-4" />
        All products
      </Link>
      <div className="grid gap-8 md:grid-cols-2">
        <div className="overflow-hidden rounded-xl bg-surface shadow-[var(--shadow-border)]">
          <img
            src={product.image}
            alt={product.name}
            className="aspect-square w-full object-cover"
          />
        </div>
        <div>
          <p className="text-sm text-muted">{product.category}</p>
          <h1 className="mt-1 font-display text-3xl font-medium">{product.name}</h1>
          <p className="mt-3 font-display text-2xl tabular-nums">
            {formatMoney(product.price, currency)}
          </p>
          <p className="mt-4 max-w-md text-muted">{product.description}</p>
          <p className="mt-3 text-sm text-muted">
            {soldOut ? "Currently sold out" : `${product.stock} in stock`}
          </p>
          <Button
            size="lg"
            className="mt-6 w-full sm:w-auto"
            disabled={soldOut}
            onClick={() => addToCart(product.id)}
          >
            {soldOut ? "Sold out" : "Add to bag"}
          </Button>
        </div>
      </div>
    </div>
  );
}
