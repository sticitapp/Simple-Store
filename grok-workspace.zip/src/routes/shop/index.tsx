import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { ProductCard } from "@/components/product-card";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { CATEGORIES } from "@/store/defaults";
import { useShop } from "@/store/shop-store";

export const Route = createFileRoute("/shop/")({ component: ShopHome });

function ShopHome() {
  const settings = useShop((s) => s.settings);
  const products = useShop((s) => s.products);
  const [category, setCategory] = useState<(typeof CATEGORIES)[number]>("All");

  const featured = products.filter((p) => p.featured);
  const visible =
    category === "All"
      ? products
      : products.filter((p) => p.category === category);

  return (
    <div>
      <section className="stagger-in mb-12 overflow-hidden rounded-xl bg-primary px-6 py-10 text-primary-fg md:px-10">
        <p className="text-sm font-medium text-primary-fg/80">{settings.tagline}</p>
        <h1 className="mt-2 font-display text-4xl font-medium">{settings.name}</h1>
        <p className="mt-3 max-w-xl text-primary-fg/85">
          Small-batch pieces. Pay by EFT or order on WhatsApp.
        </p>
      </section>

      {featured.length > 0 && category === "All" ? (
        <section className="mb-12">
          <h2 className="mb-5 font-display text-2xl font-medium">Featured</h2>
          <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
            {featured.slice(0, 4).map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </section>
      ) : null}

      <section>
        <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <h2 className="font-display text-2xl font-medium">All products</h2>
          <div className="flex flex-wrap gap-1">
            {CATEGORIES.map((c) => (
              <Button
                key={c}
                size="sm"
                variant={category === c ? "default" : "ghost"}
                onClick={() => setCategory(c)}
              >
                {c}
              </Button>
            ))}
          </div>
        </div>
        {visible.length === 0 ? (
          <p className={cn("rounded-lg bg-surface p-8 text-sm text-muted shadow-[var(--shadow-border)]")}>
            No products in this category yet. Add some in Admin.
          </p>
        ) : (
          <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
            {visible.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
