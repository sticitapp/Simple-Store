export const MAX_PRODUCTS = 50;

export type Product = {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
  category: string;
  stock: number;
  featured: boolean;
};

export type DeliveryOption = {
  id: string;
  name: string;
  description: string;
  price: number;
  eta: string;
};

export type BankDetails = {
  accountName: string;
  bankName: string;
  accountNumber: string;
  branchCode: string;
  accountType: string;
};

export type StoreSettings = {
  name: string;
  tagline: string;
  logo: string | null;
  primaryColor: string;
  whatsapp: string;
  currency: string;
  bank: BankDetails;
  announcement: string;
};

export type CartItem = {
  productId: string;
  qty: number;
};

export type CartLine = {
  productId: string;
  name: string;
  price: number;
  image: string;
  qty: number;
};

export type PlacedOrder = {
  id: string;
  createdAt: string;
  customerName: string;
  phone: string;
  email: string;
  address: string;
  notes: string;
  deliveryId: string;
  items: { productId: string; name: string; qty: number; price: number }[];
  subtotal: number;
  deliveryPrice: number;
  total: number;
  reference: string;
};

export type ShopSnapshot = {
  settings: StoreSettings;
  products: Product[];
  delivery: DeliveryOption[];
  orders: PlacedOrder[];
};
