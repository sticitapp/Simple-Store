import { create } from "zustand";
import { persist } from "zustand/middleware";

type AccessState = {
  unlocked: boolean;
  hydrated: boolean;
  failCount: number;
  setHydrated: () => void;
  unlock: () => void;
  lock: () => void;
  bumpFail: () => void;
  resetFails: () => void;
};

export const useAccess = create<AccessState>()(
  persist(
    (set) => ({
      unlocked: false,
      hydrated: false,
      failCount: 0,
      setHydrated: () => set({ hydrated: true }),
      unlock: () => set({ unlocked: true, failCount: 0 }),
      lock: () => set({ unlocked: false }),
      bumpFail: () => set((s) => ({ failCount: s.failCount + 1 })),
      resetFails: () => set({ failCount: 0 }),
    }),
    {
      name: "mss-access",
      skipHydration: true,
      partialize: (s) => ({ unlocked: s.unlocked }),
    },
  ),
);
