import { create } from "zustand";
import { persist } from "zustand/middleware";
import { formatOrderRef } from "@/lib/format";
import {
  DEFAULT_DELIVERY,
  DEFAULT_PRODUCTS,
  DEFAULT_SETTINGS,
} from "@/store/defaults";
import type {
  CartItem,
  CartLine,
  DeliveryOption,
  PlacedOrder,
  Product,
  ShopSnapshot,
  StoreSettings,
} from "@/store/types";
import { MAX_PRODUCTS } from "@/store/types";

type ShopState = {
  settings: StoreSettings;
  products: Product[];
  delivery: DeliveryOption[];
  cart: CartItem[];
  orders: PlacedOrder[];
  cartOpen: boolean;
  setCartOpen: (open: boolean) => void;
  updateSettings: (patch: Partial<StoreSettings>) => void;
  updateBank: (patch: Partial<StoreSettings["bank"]>) => void;
  addProduct: (product: Product) => boolean;
  updateProduct: (id: string, patch: Partial<Product>) => void;
  removeProduct: (id: string) => void;
  addDelivery: (option: DeliveryOption) => void;
  updateDelivery: (id: string, patch: Partial<DeliveryOption>) => void;
  removeDelivery: (id: string) => void;
  addToCart: (productId: string, qty?: number) => void;
  setQty: (productId: string, qty: number) => void;
  removeFromCart: (productId: string) => void;
  clearCart: () => void;
  placeOrder: (input: {
    customerName: string;
    phone: string;
    email: string;
    address: string;
    notes: string;
    deliveryId: string;
  }) => PlacedOrder | null;
  restore: (snapshot: ShopSnapshot) => void;
  resetDemo: () => void;
};

function linesFrom(
  cart: CartItem[],
  products: Product[],
): CartLine[] {
  return cart
    .map((item) => {
      const product = products.find((p) => p.id === item.productId);
      if (!product) return null;
      return {
        productId: product.id,
        name: product.name,
        price: product.price,
        image: product.image,
        qty: item.qty,
      };
    })
    .filter((x): x is CartLine => x !== null);
}

export function cartLines(state: Pick<ShopState, "cart" | "products">): CartLine[] {
  return linesFrom(state.cart, state.products);
}

export function cartCount(cart: CartItem[]): number {
  return cart.reduce((sum, item) => sum + item.qty, 0);
}

export function cartSubtotal(lines: CartLine[]): number {
  return lines.reduce((sum, line) => sum + line.price * line.qty, 0);
}

export const useShop = create<ShopState>()(
  persist(
    (set, get) => ({
      settings: DEFAULT_SETTINGS,
      products: DEFAULT_PRODUCTS,
      delivery: DEFAULT_DELIVERY,
      cart: [],
      orders: [],
      cartOpen: false,
      setCartOpen: (open) => set({ cartOpen: open }),
      updateSettings: (patch) =>
        set((s) => ({ settings: { ...s.settings, ...patch } })),
      updateBank: (patch) =>
        set((s) => ({
          settings: { ...s.settings, bank: { ...s.settings.bank, ...patch } },
        })),
      addProduct: (product) => {
        const { products } = get();
        if (products.length >= MAX_PRODUCTS) return false;
        set({ products: [product, ...products] });
        return true;
      },
      updateProduct: (id, patch) =>
        set((s) => ({
          products: s.products.map((p) => (p.id === id ? { ...p, ...patch } : p)),
        })),
      removeProduct: (id) =>
        set((s) => ({
          products: s.products.filter((p) => p.id !== id),
          cart: s.cart.filter((c) => c.productId !== id),
        })),
      addDelivery: (option) =>
        set((s) => ({ delivery: [...s.delivery, option] })),
      updateDelivery: (id, patch) =>
        set((s) => ({
          delivery: s.delivery.map((d) => (d.id === id ? { ...d, ...patch } : d)),
        })),
      removeDelivery: (id) =>
        set((s) => ({ delivery: s.delivery.filter((d) => d.id !== id) })),
      addToCart: (productId, qty = 1) => {
        const product = get().products.find((p) => p.id === productId);
        if (!product || product.stock <= 0) return;
        set((s) => {
          const existing = s.cart.find((c) => c.productId === productId);
          const nextQty = Math.min(
            product.stock,
            (existing?.qty ?? 0) + qty,
          );
          const cart = existing
            ? s.cart.map((c) =>
                c.productId === productId ? { ...c, qty: nextQty } : c,
              )
            : [...s.cart, { productId, qty: nextQty }];
          return { cart, cartOpen: true };
        });
      },
      setQty: (productId, qty) =>
        set((s) => {
          const product = s.products.find((p) => p.id === productId);
          const max = product?.stock ?? 0;
          if (qty <= 0) {
            return { cart: s.cart.filter((c) => c.productId !== productId) };
          }
          return {
            cart: s.cart.map((c) =>
              c.productId === productId
                ? { ...c, qty: Math.min(max, qty) }
                : c,
            ),
          };
        }),
      removeFromCart: (productId) =>
        set((s) => ({
          cart: s.cart.filter((c) => c.productId !== productId),
        })),
      clearCart: () => set({ cart: [] }),
      placeOrder: (input) => {
        const state = get();
        const lines = linesFrom(state.cart, state.products);
        if (lines.length === 0) return null;
        const delivery = state.delivery.find((d) => d.id === input.deliveryId);
        const subtotal = cartSubtotal(lines);
        const deliveryPrice = delivery?.price ?? 0;
        const id =
          typeof crypto !== "undefined" && crypto.randomUUID
            ? crypto.randomUUID()
            : `${Date.now()}`;
        const order: PlacedOrder = {
          id,
          createdAt: new Date().toISOString(),
          customerName: input.customerName,
          phone: input.phone,
          email: input.email,
          address: input.address,
          notes: input.notes,
          deliveryId: input.deliveryId,
          items: lines.map((l) => ({
            productId: l.productId,
            name: l.name,
            qty: l.qty,
            price: l.price,
          })),
          subtotal,
          deliveryPrice,
          total: subtotal + deliveryPrice,
          reference: formatOrderRef(id),
        };
        set((s) => ({
          orders: [order, ...s.orders],
          cart: [],
          products: s.products.map((p) => {
            const line = lines.find((l) => l.productId === p.id);
            if (!line) return p;
            return { ...p, stock: Math.max(0, p.stock - line.qty) };
          }),
        }));
        return order;
      },
      restore: (snapshot) =>
        set({
          settings: snapshot.settings,
          products: snapshot.products.slice(0, MAX_PRODUCTS),
          delivery: snapshot.delivery,
          orders: snapshot.orders ?? [],
        }),
      resetDemo: () =>
        set({
          settings: DEFAULT_SETTINGS,
          products: DEFAULT_PRODUCTS,
          delivery: DEFAULT_DELIVERY,
          cart: [],
          orders: [],
        }),
    }),
    {
      name: "my-simple-store",
      skipHydration: true,
      partialize: (s) => ({
        settings: s.settings,
        products: s.products,
        delivery: s.delivery,
        cart: s.cart,
        orders: s.orders,
      }),
      onRehydrateStorage: () => (state) => {
        if (state?.settings.primaryColor === "#5b21b6") {
          state.updateSettings({ primaryColor: "#7c3aed" });
        }
      },
    },
  ),
);
