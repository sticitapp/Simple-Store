import type { DeliveryOption, Product, StoreSettings } from "@/store/types";

export const DEFAULT_SETTINGS: StoreSettings = {
  name: "Saffron Street",
  tagline: "Quiet objects for a slower home.",
  logo: null,
  primaryColor: "#7c3aed",
  whatsapp: "27821234567",
  currency: "ZAR",
  announcement: "Free collection in Cape Town · EFT or WhatsApp to order",
  bank: {
    accountName: "Saffron Street Studio",
    bankName: "Standard Bank",
    accountNumber: "123456789",
    branchCode: "051001",
    accountType: "Business current",
  },
};

export const DEFAULT_PRODUCTS: Product[] = [
  {
    id: "candle",
    name: "Amber Cedar Candle",
    description:
      "Hand-poured soy wax in a re-usable amber jar. Cedarwood, smoke and a little sweet orange. Burns about 40 hours.",
    price: 185,
    image: "/products/candle.jpg",
    category: "Home",
    stock: 18,
    featured: true,
  },
  {
    id: "throw",
    name: "Oatmeal Linen Throw",
    description:
      "Washed European linen, 140 × 200 cm. Soft from the first evening on the sofa. Stone-washed so it never looks stiff.",
    price: 650,
    image: "/products/throw.jpg",
    category: "Home",
    stock: 7,
    featured: true,
  },
  {
    id: "mug",
    name: "Speckled Stoneware Mug",
    description:
      "Thrown in small batches. Oatmeal glaze with a dark speckled clay body. Holds 350 ml — a proper morning cup.",
    price: 145,
    image: "/products/mug.jpg",
    category: "Home",
    stock: 24,
    featured: false,
  },
  {
    id: "soap",
    name: "Botanical Soap Trio",
    description:
      "Three cold-process bars: rosemary, oatmeal honey, and clay. Dried petals on the face, no plastic wrap.",
    price: 220,
    image: "/products/soap.jpg",
    category: "Body",
    stock: 15,
    featured: false,
  },
  {
    id: "incense",
    name: "Brass Incense Dish",
    description:
      "Hammered brass, roughly 10 cm across. Catches ash cleanly and ages to a softer gold. Incense stick included.",
    price: 165,
    image: "/products/incense.jpg",
    category: "Home",
    stock: 12,
    featured: false,
  },
  {
    id: "basket",
    name: "Seagrass Market Basket",
    description:
      "Handwoven seagrass with vegetable-tanned leather handles. Weekend market size — sturdy enough for bottles.",
    price: 380,
    image: "/products/basket.jpg",
    category: "Home",
    stock: 9,
    featured: true,
  },
  {
    id: "face-oil",
    name: "Rosehip Face Oil",
    description:
      "Cold-pressed rosehip with a drop of vitamin E. 30 ml glass dropper. For dry skin, scars, and winter cheeks.",
    price: 295,
    image: "/products/face-oil.jpg",
    category: "Body",
    stock: 20,
    featured: true,
  },
  {
    id: "necklace",
    name: "Terracotta Collar Necklace",
    description:
      "Hand-strung clay, cream bone and brass beads. Sits close to the collarbone. Each one is slightly different.",
    price: 420,
    image: "/products/necklace.jpg",
    category: "Wear",
    stock: 6,
    featured: false,
  },
  {
    id: "tea-towel",
    name: "Botanical Linen Tea Towel",
    description:
      "Heavy linen with a sage and terracotta plant print. Absorbent enough for dishes, handsome enough on a hook.",
    price: 125,
    image: "/products/tea-towel.jpg",
    category: "Home",
    stock: 30,
    featured: false,
  },
  {
    id: "protea",
    name: "Dried Protea Bunch",
    description:
      "Cape protea and eucalyptus, tied with twine. Lasts months in a dry room. No water, no fuss.",
    price: 240,
    image: "/products/protea.jpg",
    category: "Botanicals",
    stock: 11,
    featured: true,
  },
];

export const DEFAULT_DELIVERY: DeliveryOption[] = [
  {
    id: "collect",
    name: "Collection",
    description: "Pick up from the studio in Woodstock, Cape Town.",
    price: 0,
    eta: "Same day",
  },
  {
    id: "local",
    name: "Cape Town courier",
    description: "Door to door in greater Cape Town.",
    price: 75,
    eta: "1–2 days",
  },
  {
    id: "national",
    name: "National courier",
    description: "Door to door anywhere in South Africa.",
    price: 120,
    eta: "2–5 days",
  },
  {
    id: "paxi",
    name: "Pep Paxi",
    description: "Collect at your nearest Pep or Ackermans.",
    price: 65,
    eta: "3–6 days",
  },
];

export const CATEGORIES = ["All", "Home", "Body", "Wear", "Botanicals"] as const;
