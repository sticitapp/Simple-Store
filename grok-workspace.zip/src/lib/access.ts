/**
 * Public commerce config. The Buy button uses `paymentUrl`.
 * Paste a PayFast / PayPal / Gumroad checkout link here so every visitor
 * pays before they receive an access code.
 */
export const ACCESS = {
  priceLabel: "$30",
  paymentUrl: "",
} as const;
