import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

export const verifyLicense = createServerFn({ method: "POST" })
  .validator(
    z.object({
      code: z.string().min(1).max(80),
    }),
  )
  .handler(async ({ data }) => {
    const { checkLicense } = await import("./license-check.server");
    return checkLicense(data.code);
  });
