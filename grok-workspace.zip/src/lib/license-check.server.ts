const LICENSE_HASH =
  "aa153b218849e0659f43f5dfa0d3efef2d81f805dc86fd9af006a64967584333";

function normalize(code: string): string {
  return code.trim().toUpperCase().replace(/[\s-]+/g, "");
}

async function sha256Hex(text: string): Promise<string> {
  const data = new TextEncoder().encode(text);
  const buf = await crypto.subtle.digest("SHA-256", data);
  return [...new Uint8Array(buf)]
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

export async function checkLicense(code: string): Promise<{ ok: boolean }> {
  const hash = await sha256Hex(normalize(code));
  return { ok: hash === LICENSE_HASH };
}
