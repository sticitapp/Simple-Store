export type DemandLevel = "low" | "medium" | "high";
export type TrendKind = "evergreen" | "seasonal" | "fad";
export type ShipEase = "easy" | "typical" | "hard";

export type EvalInput = {
  name: string;
  cost: number;
  sell: number;
  demand: DemandLevel;
  competition: DemandLevel;
  shipping: ShipEase;
  uniqueness: DemandLevel;
  trend: TrendKind;
  fragility: boolean;
};

export type EvalResult = {
  score: number;
  grade: "A" | "B" | "C" | "D" | "F";
  verdict: string;
  margin: number;
  marginLabel: string;
  reasons: { label: string; detail: string; tone: "good" | "warn" | "bad" }[];
};

const LEVEL = { low: 1, medium: 2, high: 3 } as const;

export function evaluateProduct(input: EvalInput): EvalResult {
  const margin =
    input.sell > 0 ? (input.sell - input.cost) / input.sell : 0;

  let score = 0;
  const reasons: EvalResult["reasons"] = [];

  if (margin >= 0.6) {
    score += 30;
    reasons.push({
      label: "Strong margin",
      detail: `${Math.round(margin * 100)}% left after cost — room for ads, returns and delivery.`,
      tone: "good",
    });
  } else if (margin >= 0.4) {
    score += 22;
    reasons.push({
      label: "Healthy margin",
      detail: `${Math.round(margin * 100)}% is workable if shipping stays cheap.`,
      tone: "good",
    });
  } else if (margin >= 0.25) {
    score += 12;
    reasons.push({
      label: "Tight margin",
      detail: `${Math.round(margin * 100)}% — one return or a courier hike wipes the profit.`,
      tone: "warn",
    });
  } else {
    score += 4;
    reasons.push({
      label: "Weak margin",
      detail: "Selling price is too close to cost. Raise price or find a cheaper supplier.",
      tone: "bad",
    });
  }

  score += LEVEL[input.demand] * 10;
  if (input.demand === "high") {
    reasons.push({
      label: "Demand looks real",
      detail: "People already search for and buy this kind of product.",
      tone: "good",
    });
  } else if (input.demand === "low") {
    reasons.push({
      label: "Quiet demand",
      detail: "You will have to create the market, not just stock it.",
      tone: "warn",
    });
  }

  score += (4 - LEVEL[input.competition]) * 8;
  if (input.competition === "high") {
    reasons.push({
      label: "Crowded category",
      detail: "Price and photos will have to work harder than the product itself.",
      tone: "warn",
    });
  } else if (input.competition === "low") {
    reasons.push({
      label: "Open lane",
      detail: "Fewer lookalikes — easier to own the search and the look.",
      tone: "good",
    });
  }

  score += (4 - (input.shipping === "easy" ? 1 : input.shipping === "typical" ? 2 : 3)) * 6;
  if (input.shipping === "hard") {
    reasons.push({
      label: "Painful to ship",
      detail: "Bulky, heavy or awkward parcels eat margin and cause damage claims.",
      tone: "bad",
    });
  } else if (input.shipping === "easy") {
    reasons.push({
      label: "Ships cleanly",
      detail: "Small and light — cheaper courier and fewer broken-in-transit issues.",
      tone: "good",
    });
  }

  score += LEVEL[input.uniqueness] * 5;
  if (input.uniqueness === "high") {
    reasons.push({
      label: "Ownable product",
      detail: "A distinctive item is easier to brand and harder to undercut.",
      tone: "good",
    });
  }

  if (input.trend === "evergreen") {
    score += 10;
    reasons.push({
      label: "Evergreen",
      detail: "Sells in more than one season — leftover stock is less of a bet.",
      tone: "good",
    });
  } else if (input.trend === "seasonal") {
    score += 5;
    reasons.push({
      label: "Seasonal",
      detail: "Plan stock around a window. Miss it and you sit on inventory.",
      tone: "warn",
    });
  } else {
    reasons.push({
      label: "Trend risk",
      detail: "Fads fade. Only stock what you can sell in weeks, not months.",
      tone: "bad",
    });
  }

  if (input.fragility) {
    score -= 8;
    reasons.push({
      label: "Fragile",
      detail: "Extra packing cost and a higher chance of refunds.",
      tone: "warn",
    });
  }

  score = Math.max(0, Math.min(100, Math.round(score)));

  const grade: EvalResult["grade"] =
    score >= 80 ? "A" : score >= 65 ? "B" : score >= 50 ? "C" : score >= 35 ? "D" : "F";

  const verdict =
    grade === "A"
      ? "Stock it. The numbers and the market both support a listing."
      : grade === "B"
        ? "Worth selling — keep a tight hold on cost and shipping."
        : grade === "C"
          ? "Only if you already have an audience or a cheaper source."
          : grade === "D"
            ? "Risky. Change price, supplier or product before you buy in bulk."
            : "Skip it. The margin, demand or logistics do not add up.";

  const marginLabel =
    margin <= 0 ? "Loss" : `${Math.round(margin * 100)}% margin`;

  return { score, grade, verdict, margin, marginLabel, reasons };
}
