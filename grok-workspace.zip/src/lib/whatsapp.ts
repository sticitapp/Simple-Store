import { digitsOnly, formatMoney } from "@/lib/format";
import type { CartLine, DeliveryOption, StoreSettings } from "@/store/types";

export function waLink(phone: string, text: string): string {
  const digits = digitsOnly(phone);
  return `https://wa.me/${digits}?text=${encodeURIComponent(text)}`;
}

export function enquiryMessage(settings: StoreSettings): string {
  return `Hi ${settings.name}, I'd like to ask about your products.`;
}

export function orderMessage(opts: {
  settings: StoreSettings;
  customerName: string;
  phone: string;
  address: string;
  notes: string;
  lines: CartLine[];
  delivery: DeliveryOption | undefined;
  total: number;
  reference: string;
}): string {
  const items = opts.lines
    .map(
      (l) =>
        `• ${l.qty}× ${l.name} — ${formatMoney(l.price * l.qty, opts.settings.currency)}`,
    )
    .join("\n");
  const delivery = opts.delivery
    ? `${opts.delivery.name} (${formatMoney(opts.delivery.price, opts.settings.currency)})`
    : "Not selected";
  const notes = opts.notes.trim() ? `\nNotes: ${opts.notes.trim()}` : "";
  return `New order for ${opts.settings.name}

${items}

Delivery: ${delivery}
Total: ${formatMoney(opts.total, opts.settings.currency)}
Reference: ${opts.reference}

Name: ${opts.customerName}
Phone: ${opts.phone}
Address: ${opts.address}${notes}

I'll pay by EFT using the reference above.`;
}
