const CURRENCY_LOCALES: Record<string, string> = {
  ZAR: "en-ZA",
  USD: "en-US",
  GBP: "en-GB",
  EUR: "en-IE",
  AUD: "en-AU",
};

export function formatMoney(amount: number, currency = "ZAR"): string {
  const locale = CURRENCY_LOCALES[currency] ?? "en-ZA";
  try {
    return new Intl.NumberFormat(locale, {
      style: "currency",
      currency,
      maximumFractionDigits: 0,
    }).format(amount);
  } catch {
    return `${currency} ${amount}`;
  }
}

export function formatOrderRef(id: string): string {
  return `MSS-${id.slice(0, 6).toUpperCase()}`;
}

export function digitsOnly(value: string): string {
  return value.replace(/\D/g, "");
}
