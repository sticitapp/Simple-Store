import { useEffect } from "react";
import { useShop } from "@/store/shop-store";

export function StoreTheme() {
  const name = useShop((s) => s.settings.name);
  const color = useShop((s) => s.settings.primaryColor);

  useEffect(() => {
    const root = document.documentElement;
    root.style.setProperty("--color-primary", color);
    root.style.setProperty("--color-ring", color);
    const fg = contrastOn(color);
    root.style.setProperty("--color-primary-fg", fg);
    document.title = name.trim() || "My Simple Store";
  }, [color, name]);

  return null;
}

function contrastOn(hex: string): string {
  const raw = hex.replace("#", "");
  if (raw.length !== 6) return "#faf5ff";
  const r = parseInt(raw.slice(0, 2), 16) / 255;
  const g = parseInt(raw.slice(2, 4), 16) / 255;
  const b = parseInt(raw.slice(4, 6), 16) / 255;
  const lum = 0.2126 * r + 0.7152 * g + 0.0722 * b;
  return lum > 0.62 ? "#1c1917" : "#faf5ff";
}
