import { FormEvent, useState, type ReactNode } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { Lock } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ACCESS } from "@/lib/access";
import { verifyLicense } from "@/lib/license";
import { useAccess } from "@/store/access-store";

export function Paywall({ next = "/admin" }: { next?: string }) {
  const unlock = useAccess((s) => s.unlock);
  const bumpFail = useAccess((s) => s.bumpFail);
  const failCount = useAccess((s) => s.failCount);
  const [code, setCode] = useState("");
  const [busy, setBusy] = useState(false);
  const navigate = useNavigate();
  const lockedOut = failCount >= 6;

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    if (lockedOut || busy) return;
    setBusy(true);
    try {
      const result = await verifyLicense({ data: { code } });
      if (!result.ok) {
        bumpFail();
        toast.error("That code is not valid.");
        return;
      }
      unlock();
      toast.success("Unlocked on this device.");
      void navigate({ to: next });
    } catch {
      toast.error("Could not check the code. Try again.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="mx-auto max-w-md py-6">
      <div className="flex size-10 items-center justify-center rounded-md bg-primary text-primary-fg">
        <Lock className="size-4" />
      </div>
      <h1 className="mt-4 font-display text-3xl font-medium">
        Unlock the full store
      </h1>
      <p className="mt-2 text-sm text-muted">
        Admin, branding, backup and the product evaluator are paid features.
        The demo shop stays free to browse.
      </p>

      <div className="mt-6 rounded-xl bg-surface p-6 shadow-[var(--shadow-border)]">
        <p className="font-display text-3xl font-medium text-primary">
          {ACCESS.priceLabel}
        </p>
        <p className="text-sm text-muted">One-time · this device stays unlocked</p>

        {ACCESS.paymentUrl ? (
          <Button size="lg" className="mt-5 w-full" asChild>
            <a href={ACCESS.paymentUrl} target="_blank" rel="noreferrer">
              Pay {ACCESS.priceLabel}
            </a>
          </Button>
        ) : (
          <p className="mt-4 text-sm text-muted">
            Pay {ACCESS.priceLabel} to the seller. They will send you an access
            code. Paste it below.
          </p>
        )}

        <form className="mt-6 space-y-3" onSubmit={onSubmit}>
          <div className="space-y-1.5">
            <Label htmlFor="access-code">I already paid — access code</Label>
            <Input
              id="access-code"
              autoComplete="off"
              spellCheck={false}
              placeholder="XXXX-XXXX-XXXX"
              value={code}
              onChange={(e) => setCode(e.target.value)}
              disabled={lockedOut}
            />
          </div>
          <Button
            type="submit"
            className="w-full"
            disabled={busy || lockedOut || code.trim().length < 4}
          >
            {lockedOut ? "Too many tries — wait and refresh" : "Unlock"}
          </Button>
        </form>
      </div>

      <p className="mt-6 text-center text-sm">
        <Link to="/shop" className="text-muted underline-offset-4 hover:text-fg hover:underline">
          Browse the demo shop
        </Link>
      </p>
    </div>
  );
}

export function RequirePaid({
  children,
  next,
}: {
  children: ReactNode;
  next: string;
}) {
  const unlocked = useAccess((s) => s.unlocked);
  const hydrated = useAccess((s) => s.hydrated);

  if (!hydrated) {
    return <div className="min-h-[40vh]" />;
  }
  if (!unlocked) {
    return <Paywall next={next} />;
  }
  return children;
}
