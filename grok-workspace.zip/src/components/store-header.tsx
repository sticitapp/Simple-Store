import { Link, useRouterState } from "@tanstack/react-router";
import { ShoppingBag } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { cartCount, useShop } from "@/store/shop-store";

const NAV = [
  { to: "/shop", label: "Shop", exact: true },
  { to: "/evaluate", label: "Evaluator" },
  { to: "/admin", label: "Admin" },
] as const;

export function StoreHeader() {
  const settings = useShop((s) => s.settings);
  const cart = useShop((s) => s.cart);
  const setCartOpen = useShop((s) => s.setCartOpen);
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const count = cartCount(cart);

  return (
    <header className="sticky top-0 z-40 border-b border-border bg-bg/90 backdrop-blur-md">
      {settings.announcement ? (
        <p className="bg-primary px-4 py-2 text-center text-xs font-medium tracking-wide text-primary-fg">
          {settings.announcement}
        </p>
      ) : null}
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-3 px-4">
        <Link to="/shop" className="flex min-w-0 items-center gap-2.5">
          {settings.logo ? (
            <img
              src={settings.logo}
              alt=""
              className="size-8 rounded-sm object-cover"
            />
          ) : (
            <span className="flex size-8 items-center justify-center rounded-sm bg-primary font-display text-sm text-primary-fg">
              {settings.name.slice(0, 1)}
            </span>
          )}
          <span className="truncate font-display text-lg font-medium tracking-tight">
            {settings.name}
          </span>
        </Link>

        <nav className="hidden items-center gap-1 md:flex">
          {NAV.map((item) => {
            const active =
              "exact" in item && item.exact
                ? pathname === item.to
                : pathname.startsWith(item.to);
            return (
              <Link
                key={item.to}
                to={item.to}
                className={cn(
                  "rounded-md px-3 py-2 text-sm font-medium transition-colors duration-150",
                  active ? "bg-surface text-fg" : "text-muted hover:text-fg",
                )}
              >
                {item.label}
              </Link>
            );
          })}
        </nav>

        <div className="flex items-center gap-1">
          <Link
            to="/admin"
            className="rounded-md px-3 py-2 text-sm font-medium text-muted hover:text-fg md:hidden"
          >
            Admin
          </Link>
          <Button
            variant="secondary"
            size="icon"
            aria-label={`Open bag, ${count} items`}
            onClick={() => setCartOpen(true)}
            className="relative"
          >
            <ShoppingBag />
            {count > 0 ? (
              <span className="absolute -right-1 -top-1 flex size-5 items-center justify-center rounded-full bg-primary text-[10px] font-semibold text-primary-fg tabular-nums">
                {count}
              </span>
            ) : null}
          </Button>
        </div>
      </div>
    </header>
  );
}
