import { Link } from "@tanstack/react-router";
import { Minus, Plus, Trash2 } from "lucide-react";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { formatMoney } from "@/lib/format";
import { cartLines, cartSubtotal, useShop } from "@/store/shop-store";

export function CartSheet() {
  const open = useShop((s) => s.cartOpen);
  const setCartOpen = useShop((s) => s.setCartOpen);
  const cart = useShop((s) => s.cart);
  const products = useShop((s) => s.products);
  const settings = useShop((s) => s.settings);
  const setQty = useShop((s) => s.setQty);
  const removeFromCart = useShop((s) => s.removeFromCart);
  const lines = cartLines({ cart, products });
  const subtotal = cartSubtotal(lines);

  return (
    <Sheet open={open} onOpenChange={setCartOpen}>
      <SheetContent>
        <SheetHeader>
          <SheetTitle>Your bag</SheetTitle>
          <SheetDescription>
            {lines.length === 0
              ? "Nothing in here yet."
              : `${lines.length} ${lines.length === 1 ? "item" : "items"}`}
          </SheetDescription>
        </SheetHeader>

        <div className="flex min-h-0 flex-1 flex-col">
          <div className="flex-1 overflow-y-auto px-6">
            {lines.length === 0 ? (
              <p className="text-sm text-muted">
                Browse the shop and add a few things. You can check out by EFT
                or WhatsApp.
              </p>
            ) : (
              <ul className="space-y-4">
                {lines.map((line) => (
                  <li key={line.productId} className="flex gap-3">
                    <img
                      src={line.image}
                      alt=""
                      className="size-20 rounded-md object-cover"
                    />
                    <div className="min-w-0 flex-1">
                      <p className="truncate font-medium">{line.name}</p>
                      <p className="text-sm tabular-nums text-muted">
                        {formatMoney(line.price, settings.currency)}
                      </p>
                      <div className="mt-2 flex items-center gap-2">
                        <Button
                          variant="outline"
                          size="icon"
                          className="size-8"
                          aria-label="Decrease quantity"
                          onClick={() => setQty(line.productId, line.qty - 1)}
                        >
                          <Minus />
                        </Button>
                        <span className="w-6 text-center text-sm tabular-nums">
                          {line.qty}
                        </span>
                        <Button
                          variant="outline"
                          size="icon"
                          className="size-8"
                          aria-label="Increase quantity"
                          onClick={() => setQty(line.productId, line.qty + 1)}
                        >
                          <Plus />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="ml-auto size-8 text-muted"
                          aria-label={`Remove ${line.name}`}
                          onClick={() => removeFromCart(line.productId)}
                        >
                          <Trash2 />
                        </Button>
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>

          <div className="border-t border-border p-6">
            <div className="mb-4 flex items-center justify-between text-sm">
              <span className="text-muted">Subtotal</span>
              <span className="tabular-nums font-medium">
                {formatMoney(subtotal, settings.currency)}
              </span>
            </div>
            {lines.length === 0 ? (
              <Button className="w-full" disabled>
                Checkout
              </Button>
            ) : (
              <Button asChild className="w-full">
                <Link to="/checkout" onClick={() => setCartOpen(false)}>
                  Checkout
                </Link>
              </Button>
            )}
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}
