import { Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { formatMoney } from "@/lib/format";
import { useShop } from "@/store/shop-store";
import type { Product } from "@/store/types";

export function ProductCard({ product }: { product: Product }) {
  const addToCart = useShop((s) => s.addToCart);
  const currency = useShop((s) => s.settings.currency);
  const soldOut = product.stock <= 0;

  return (
    <article>
      <Link
        to="/shop/$productId"
        params={{ productId: product.id }}
        className="group block"
      >
        <div className="overflow-hidden rounded-xl bg-surface shadow-[var(--shadow-border)]">
          <img
            src={product.image}
            alt={product.name}
            className="aspect-square w-full object-cover outline-none transition-transform duration-500 ease-out group-hover:scale-[1.03]"
          />
        </div>
        <div className="mt-3 flex items-start justify-between gap-3">
          <div className="min-w-0">
            <h3 className="truncate font-medium text-fg">{product.name}</h3>
            <p className="text-sm text-muted">{product.category}</p>
          </div>
          <p className="shrink-0 tabular-nums font-medium text-primary">
            {formatMoney(product.price, currency)}
          </p>
        </div>
      </Link>
      <Button
        className="mt-3 w-full"
        disabled={soldOut}
        onClick={() => addToCart(product.id)}
      >
        {soldOut ? "Sold out" : "Add to bag"}
      </Button>
    </article>
  );
}
