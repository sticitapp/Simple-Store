import { useEffect, type ReactNode } from "react";
import { StoreTheme } from "@/components/store-theme";
import { useAccess } from "@/store/access-store";
import { useShop } from "@/store/shop-store";

export function ShopProvider({ children }: { children: ReactNode }) {
  useEffect(() => {
    void Promise.all([
      useShop.persist.rehydrate(),
      useAccess.persist.rehydrate(),
    ]).then(() => {
      useAccess.getState().setHydrated();
    });
  }, []);
  return (
    <>
      <StoreTheme />
      {children}
    </>
  );
}
