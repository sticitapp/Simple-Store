import { MessageCircle } from "lucide-react";
import { enquiryMessage, waLink } from "@/lib/whatsapp";
import { useShop } from "@/store/shop-store";

export function WhatsappFab() {
  const settings = useShop((s) => s.settings);
  if (!settings.whatsapp) return null;

  return (
    <a
      href={waLink(settings.whatsapp, enquiryMessage(settings))}
      target="_blank"
      rel="noreferrer"
      className="fixed bottom-6 left-4 z-40 inline-flex h-12 items-center gap-2 rounded-full bg-success px-4 text-sm font-medium text-surface shadow-[var(--shadow-border-hover)] transition-transform duration-150 active:scale-[0.96]"
    >
      <MessageCircle className="size-4" />
      WhatsApp
    </a>
  );
}
