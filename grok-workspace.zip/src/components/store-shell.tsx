import type { ReactNode } from "react";
import { CartSheet } from "@/components/cart-sheet";
import { StoreHeader } from "@/components/store-header";
import { WhatsappFab } from "@/components/whatsapp-fab";

export function StoreShell({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen bg-bg">
      <StoreHeader />
      <main className="mx-auto w-full max-w-6xl px-4 py-8 pb-28">{children}</main>
      <CartSheet />
      <WhatsappFab />
    </div>
  );
}
